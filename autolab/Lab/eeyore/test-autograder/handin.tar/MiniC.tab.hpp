/* A Bison parser, made by GNU Bison 3.0.4.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_HOME_LEEWY_GIT_MINICCOMPILER_SRC_PARSER_MINIC_TAB_HPP_INCLUDED
# define YY_YY_HOME_LEEWY_GIT_MINICCOMPILER_SRC_PARSER_MINIC_TAB_HPP_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif
/* "%code requires" blocks.  */
#line 16 "MiniC.y" /* yacc.c:1909  */

#include "yaccType.h"
void yyerror(const char *s);

#line 49 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.hpp" /* yacc.c:1909  */

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    IDENTIFIER = 258,
    STR_CONSTANT = 259,
    CHAR_CONSTANT = 260,
    INT_CONSTANT = 261,
    ENUM_CONSTANT = 262,
    DOUBLE_CONSTANT = 263,
    SIZEOF = 264,
    PTR_OP = 265,
    INC_OP = 266,
    DEC_OP = 267,
    LEFT_OP = 268,
    RIGHT_OP = 269,
    LE_OP = 270,
    GE_OP = 271,
    EQ_OP = 272,
    NE_OP = 273,
    AND_OP = 274,
    OR_OP = 275,
    MUL_ASSIGN = 276,
    DIV_ASSIGN = 277,
    MOD_ASSIGN = 278,
    ADD_ASSIGN = 279,
    SUB_ASSIGN = 280,
    LEFT_ASSIGN = 281,
    RIGHT_ASSIGN = 282,
    AND_ASSIGN = 283,
    XOR_ASSIGN = 284,
    OR_ASSIGN = 285,
    TYPE_NAME = 286,
    TYPEDEF = 287,
    STATIC = 288,
    CHAR = 289,
    SHORT = 290,
    INT = 291,
    LONG = 292,
    SIGNED = 293,
    UNSIGNED = 294,
    FLOAT = 295,
    DOUBLE = 296,
    CONST = 297,
    VOID = 298,
    STRUCT = 299,
    UNION = 300,
    ENUM = 301,
    CASE = 302,
    DEFAULT = 303,
    IF = 304,
    ELSE = 305,
    SWITCH = 306,
    WHILE = 307,
    DO = 308,
    FOR = 309,
    GOTO = 310,
    CONTINUE = 311,
    BREAK = 312,
    RETURN = 313,
    IFX = 314
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED

union YYSTYPE
{
#line 21 "MiniC.y" /* yacc.c:1909  */

    char *vstr;
    char vchar;
    int vint;
    double vdouble;
    void *vptr;
    type_qualifier_s_t type_qualifier_s;
    storage_class_specifier_s_t storage_class_specifier_s;
    type_specifier_s_t type_specifier_s;
    struct_or_union_s_t struct_or_union_s;
    struct_or_union_specifier_s_t struct_or_union_specifier_s;
    specifier_qualifier_list_s_t specifier_qualifier_list_s;
    declaration_specifiers_s_t declaration_specifiers_s;
    enum_specifier_s_t enum_specifier_s;
    enumerator_list_s_t enumerator_list_s;
    enumerator_s_t enumerator_s;
    expression_s_t expression_s;
    pointer_s_t pointer_s;
    direct_declarator_s_t direct_declarator_s;
    parameter_list_s_t parameter_list_s;
    declarator_s_t declarator_s;
    struct_declarator_list_s_t *struct_declarator_list_s;
    abstract_declarator_s_t abstract_declarator_s;
    direct_abstract_declarator_s_t direct_abstract_declarator_s;
    type_name_s_t type_name_s;
    initializer_list_s_t *initializer_list_s;
    initializer_s_t initializer_s;
    init_declarator_s_t init_declarator_s;
    init_declarator_list_s_t *init_declarator_list_s;
    statement_i_t statement_i;
    statement_s_t statement_s;
    expression_statement_s_t expression_statement_s;
    for_jumper2_s_t for_jumper2_s;
	argument_expression_list_s_t argument_expression_list_s;

#line 157 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.hpp" /* yacc.c:1909  */
};

typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_HOME_LEEWY_GIT_MINICCOMPILER_SRC_PARSER_MINIC_TAB_HPP_INCLUDED  */
