/* A Bison parser, made by GNU Bison 3.0.4.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "3.0.4"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* Copy the first part of user declarations.  */
#line 1 "MiniC.y" /* yacc.c:339  */


#include <cstdio>
#include "symbol.h"
#include "gen.h"
#include "yaccUtils.h"
#include "expression.h"
#include <cstdlib>
#include <cstring>
#include <string>

int yylex (void);


#line 81 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:339  */

# ifndef YY_NULLPTR
#  if defined __cplusplus && 201103L <= __cplusplus
#   define YY_NULLPTR nullptr
#  else
#   define YY_NULLPTR 0
#  endif
# endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* In a future release of Bison, this section will be replaced
   by #include "MiniC.tab.hpp".  */
#ifndef YY_YY_HOME_LEEWY_GIT_MINICCOMPILER_SRC_PARSER_MINIC_TAB_HPP_INCLUDED
# define YY_YY_HOME_LEEWY_GIT_MINICCOMPILER_SRC_PARSER_MINIC_TAB_HPP_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif
/* "%code requires" blocks.  */
#line 16 "MiniC.y" /* yacc.c:355  */

#include "yaccType.h"
void yyerror(const char *s);

#line 116 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:355  */

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    IDENTIFIER = 258,
    STR_CONSTANT = 259,
    CHAR_CONSTANT = 260,
    INT_CONSTANT = 261,
    ENUM_CONSTANT = 262,
    DOUBLE_CONSTANT = 263,
    SIZEOF = 264,
    PTR_OP = 265,
    INC_OP = 266,
    DEC_OP = 267,
    LEFT_OP = 268,
    RIGHT_OP = 269,
    LE_OP = 270,
    GE_OP = 271,
    EQ_OP = 272,
    NE_OP = 273,
    AND_OP = 274,
    OR_OP = 275,
    MUL_ASSIGN = 276,
    DIV_ASSIGN = 277,
    MOD_ASSIGN = 278,
    ADD_ASSIGN = 279,
    SUB_ASSIGN = 280,
    LEFT_ASSIGN = 281,
    RIGHT_ASSIGN = 282,
    AND_ASSIGN = 283,
    XOR_ASSIGN = 284,
    OR_ASSIGN = 285,
    TYPE_NAME = 286,
    TYPEDEF = 287,
    STATIC = 288,
    CHAR = 289,
    SHORT = 290,
    INT = 291,
    LONG = 292,
    SIGNED = 293,
    UNSIGNED = 294,
    FLOAT = 295,
    DOUBLE = 296,
    CONST = 297,
    VOID = 298,
    STRUCT = 299,
    UNION = 300,
    ENUM = 301,
    CASE = 302,
    DEFAULT = 303,
    IF = 304,
    ELSE = 305,
    SWITCH = 306,
    WHILE = 307,
    DO = 308,
    FOR = 309,
    GOTO = 310,
    CONTINUE = 311,
    BREAK = 312,
    RETURN = 313,
    IFX = 314
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED

union YYSTYPE
{
#line 21 "MiniC.y" /* yacc.c:355  */

    char *vstr;
    char vchar;
    int vint;
    double vdouble;
    void *vptr;
    type_qualifier_s_t type_qualifier_s;
    storage_class_specifier_s_t storage_class_specifier_s;
    type_specifier_s_t type_specifier_s;
    struct_or_union_s_t struct_or_union_s;
    struct_or_union_specifier_s_t struct_or_union_specifier_s;
    specifier_qualifier_list_s_t specifier_qualifier_list_s;
    declaration_specifiers_s_t declaration_specifiers_s;
    enum_specifier_s_t enum_specifier_s;
    enumerator_list_s_t enumerator_list_s;
    enumerator_s_t enumerator_s;
    expression_s_t expression_s;
    pointer_s_t pointer_s;
    direct_declarator_s_t direct_declarator_s;
    parameter_list_s_t parameter_list_s;
    declarator_s_t declarator_s;
    struct_declarator_list_s_t *struct_declarator_list_s;
    abstract_declarator_s_t abstract_declarator_s;
    direct_abstract_declarator_s_t direct_abstract_declarator_s;
    type_name_s_t type_name_s;
    initializer_list_s_t *initializer_list_s;
    initializer_s_t initializer_s;
    init_declarator_s_t init_declarator_s;
    init_declarator_list_s_t *init_declarator_list_s;
    statement_i_t statement_i;
    statement_s_t statement_s;
    expression_statement_s_t expression_statement_s;
    for_jumper2_s_t for_jumper2_s;
	argument_expression_list_s_t argument_expression_list_s;

#line 224 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:355  */
};

typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_HOME_LEEWY_GIT_MINICCOMPILER_SRC_PARSER_MINIC_TAB_HPP_INCLUDED  */

/* Copy the second part of user declarations.  */

#line 241 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:358  */

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif

#ifndef YY_ATTRIBUTE
# if (defined __GNUC__                                               \
      && (2 < __GNUC__ || (__GNUC__ == 2 && 96 <= __GNUC_MINOR__)))  \
     || defined __SUNPRO_C && 0x5110 <= __SUNPRO_C
#  define YY_ATTRIBUTE(Spec) __attribute__(Spec)
# else
#  define YY_ATTRIBUTE(Spec) /* empty */
# endif
#endif

#ifndef YY_ATTRIBUTE_PURE
# define YY_ATTRIBUTE_PURE   YY_ATTRIBUTE ((__pure__))
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# define YY_ATTRIBUTE_UNUSED YY_ATTRIBUTE ((__unused__))
#endif

#if !defined _Noreturn \
     && (!defined __STDC_VERSION__ || __STDC_VERSION__ < 201112)
# if defined _MSC_VER && 1200 <= _MSC_VER
#  define _Noreturn __declspec (noreturn)
# else
#  define _Noreturn YY_ATTRIBUTE ((__noreturn__))
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(E) ((void) (E))
#else
# define YYUSE(E) /* empty */
#endif

#if defined __GNUC__ && 407 <= __GNUC__ * 100 + __GNUC_MINOR__
/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN \
    _Pragma ("GCC diagnostic push") \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")\
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# define YY_IGNORE_MAYBE_UNINITIALIZED_END \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif


#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYSIZE_T yynewbytes;                                            \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / sizeof (*yyptr);                          \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, (Count) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYSIZE_T yyi;                         \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  44
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   977

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  84
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  99
/* YYNRULES -- Number of rules.  */
#define YYNRULES  252
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  406

/* YYTRANSLATE[YYX] -- Symbol number corresponding to YYX as returned
   by yylex, with out-of-bounds checking.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   314

#define YYTRANSLATE(YYX)                                                \
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, without out-of-bounds checking.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    73,     2,     2,     2,    75,    68,     2,
      60,    61,    69,    70,    67,    71,    64,    74,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    81,    83,
      76,    82,    77,    80,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    62,     2,    63,    78,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    65,    79,    66,    72,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59
};

#if YYDEBUG
  /* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   134,   134,   158,   161,   164,   170,   179,   188,   197,
     209,   230,   233,   282,   288,   291,   307,   330,   333,   336,
     354,   355,   359,   365,   375,   376,   380,   384,   491,   500,
     512,   513,   514,   515,   516,   517,   521,   522,   531,   532,
     533,   534,   538,   539,   540,   544,   545,   546,   550,   551,
     552,   553,   554,   558,   559,   560,   564,   565,   569,   570,
     574,   575,   579,   580,   587,   588,   595,   596,   596,   646,
     656,   657,   691,   694,   695,   696,   697,   698,   699,   700,
     701,   702,   703,   707,   708,   712,   716,   717,   721,   725,
     726,   727,   728,   729,   730,   731,   732,   733,   734,   735,
     736,   740,   741,   742,   743,   744,   745,   749,   750,   754,
     755,   759,   760,   786,   787,   791,   796,   796,   812,   817,
     822,   837,   840,   841,   842,   843,   847,   848,   852,   853,
     865,   866,   870,   871,   872,   873,   874,   886,   886,   887,
     887,   896,   898,   902,   903,   904,   905,   906,   907,   908,
     912,   913,   914,   915,   919,   920,   924,   934,   944,   957,
     957,   958,   962,   963,   967,   973,   982,   983,   984,   988,
     989,   990,   991,   992,   993,   994,   995,   996,  1000,  1001,
    1005,  1006,  1007,  1008,  1012,  1013,  1014,  1015,  1019,  1020,
    1021,  1022,  1023,  1024,  1028,  1029,  1029,  1029,  1052,  1052,
    1052,  1061,  1062,  1066,  1067,  1067,  1077,  1081,  1081,  1087,
    1091,  1092,  1096,  1096,  1096,  1103,  1104,  1104,  1104,  1124,
    1127,  1134,  1137,  1134,  1144,  1144,  1156,  1156,  1169,  1169,
    1180,  1180,  1194,  1194,  1208,  1211,  1214,  1223,  1230,  1231,
    1238,  1245,  1251,  1265,  1266,  1270,  1271,  1275,  1275,  1276,
    1276,  1306,  1307
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || 0
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "IDENTIFIER", "STR_CONSTANT",
  "CHAR_CONSTANT", "INT_CONSTANT", "ENUM_CONSTANT", "DOUBLE_CONSTANT",
  "SIZEOF", "PTR_OP", "INC_OP", "DEC_OP", "LEFT_OP", "RIGHT_OP", "LE_OP",
  "GE_OP", "EQ_OP", "NE_OP", "AND_OP", "OR_OP", "MUL_ASSIGN", "DIV_ASSIGN",
  "MOD_ASSIGN", "ADD_ASSIGN", "SUB_ASSIGN", "LEFT_ASSIGN", "RIGHT_ASSIGN",
  "AND_ASSIGN", "XOR_ASSIGN", "OR_ASSIGN", "TYPE_NAME", "TYPEDEF",
  "STATIC", "CHAR", "SHORT", "INT", "LONG", "SIGNED", "UNSIGNED", "FLOAT",
  "DOUBLE", "CONST", "VOID", "STRUCT", "UNION", "ENUM", "CASE", "DEFAULT",
  "IF", "ELSE", "SWITCH", "WHILE", "DO", "FOR", "GOTO", "CONTINUE",
  "BREAK", "RETURN", "IFX", "'('", "')'", "'['", "']'", "'.'", "'{'",
  "'}'", "','", "'&'", "'*'", "'+'", "'-'", "'~'", "'!'", "'/'", "'%'",
  "'<'", "'>'", "'^'", "'|'", "'?'", "':'", "'='", "';'", "$accept",
  "primary_expression", "constant", "string", "postfix_expression",
  "comma_or_none", "argument_expression_list", "unary_expression",
  "unary_operator", "cast_expression", "multiplicative_expression",
  "additive_expression", "shift_expression", "relational_expression",
  "equality_expression", "and_expression", "exclusive_or_expression",
  "inclusive_or_expression", "logical_and_expression",
  "logical_or_expression", "conditional_expression", "@1",
  "logical_jumper", "assignment_expression", "assignment_operator",
  "expression", "constant_expression", "storage_class_specifier",
  "type_qualifier", "type_specifier", "declaration_specifiers",
  "init_declarator", "init_declarator_list", "declaration",
  "struct_or_union", "struct_or_union_specifier", "$@2",
  "struct_push_symbol_stack", "specifier_qualifier_list",
  "struct_declarator_list", "struct_declaration",
  "struct_declaration_list", "enum_specifier", "enumerator_list", "@3",
  "@4", "enumerator", "direct_declarator", "pointer", "declarator",
  "parameter_declaration", "parameter_list", "$@5", "identifier_list",
  "type_name", "abstract_declarator", "direct_abstract_declarator",
  "designator", "initializer", "initializer_list", "statement",
  "labeled_statement", "@6", "@7", "@8", "@9", "block_item",
  "block_item_list", "@10", "compound_statement", "@11",
  "compound_push_symbol_stack_normal", "expression_statement",
  "selection_statement", "@12", "@13", "@14", "@15",
  "if_statement_inherit", "jumper", "iteration_statement", "@16", "@17",
  "@18", "@19", "@20", "@21", "@22", "for_push_symbol_stack",
  "for_jumper1", "for_jumper2", "for_jumper3", "jump_statement",
  "translation_unit", "external_declaration", "function_definition",
  "$@23", "@24", "declaration_list", YY_NULLPTR
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[NUM] -- (External) token number corresponding to the
   (internal) symbol number NUM (which must be that of a token).  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
      40,    41,    91,    93,    46,   123,   125,    44,    38,    42,
      43,    45,   126,    33,    47,    37,    60,    62,    94,   124,
      63,    58,    61,    59
};
# endif

#define YYPACT_NINF -313

#define yypact_value_is_default(Yystate) \
  (!!((Yystate) == (-313)))

#define YYTABLE_NINF -250

#define yytable_value_is_error(Yytable_value) \
  0

  /* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
     STATE-NUM.  */
static const yytype_int16 yypact[] =
{
     914,  -313,  -313,  -313,  -313,  -313,  -313,  -313,  -313,  -313,
    -313,  -313,  -313,  -313,  -313,  -313,    23,   914,   914,   914,
      12,  -313,    27,  -313,  -313,   281,  -313,  -313,   -17,  -313,
    -313,  -313,  -313,  -313,    16,   -20,  -313,  -313,   -31,    64,
      15,   801,    -5,     3,  -313,  -313,  -313,   -43,   100,    62,
      76,  -313,    16,  -313,    61,   592,    64,   606,    12,  -313,
     137,   914,   160,   862,   122,  -313,   163,   168,  -313,  -313,
    -313,  -313,   174,  -313,  -313,    29,   914,    99,  -313,  -313,
    -313,  -313,  -313,  -313,   748,   789,   789,   477,  -313,  -313,
    -313,  -313,  -313,  -313,  -313,  -313,  -313,  -313,   130,  -313,
     819,  -313,   124,   170,   245,    22,   247,   194,   190,   192,
     261,    24,  -313,   219,   491,   157,  -313,  -313,  -313,  -313,
    -313,  -313,   137,   931,   218,  -313,   931,   931,    14,  -313,
     878,  -313,   220,  -313,   100,   819,  -313,   914,    31,  -313,
    -313,   282,   477,  -313,   477,  -313,  -313,  -313,   106,    93,
     228,   288,  -313,  -313,   633,   819,   291,  -313,   819,   819,
     819,   819,   819,   819,   819,   819,   819,   819,   819,   819,
     819,   819,   819,   819,  -313,  -313,   216,  -313,   819,   294,
    -313,   606,  -313,   200,  -313,  -313,  -313,  -313,  -313,  -313,
    -313,  -313,  -313,  -313,  -313,   819,   232,  -313,   895,  -313,
    -313,  -313,  -313,   -26,  -313,  -313,  -313,  -313,  -313,  -313,
    -313,    18,   677,    11,  -313,  -313,   189,  -313,   238,   239,
    -313,   819,    96,   195,  -313,   704,  -313,  -313,   110,  -313,
     107,  -313,  -313,  -313,  -313,   124,   124,   170,   170,   245,
     245,   245,   245,    22,    22,   247,   194,   190,   819,   819,
     819,   265,  -313,  -313,  -313,   521,  -313,  -313,   299,  -313,
      16,  -313,  -313,   139,   268,  -313,   286,   189,   297,   718,
     295,   295,  -313,   562,  -313,  -313,   819,  -313,   192,   261,
     296,  -313,  -313,   606,  -313,   280,   819,  -313,   302,  -313,
     305,  -313,   306,   370,   303,   304,   388,  -313,    69,  -313,
    -313,  -313,  -313,   308,  -313,  -313,  -313,  -313,  -313,  -313,
    -313,  -313,  -313,  -313,   152,  -313,   322,   321,  -313,   309,
    -313,   372,  -313,   317,   819,   329,  -313,   372,   404,   318,
    -313,  -313,  -313,    71,  -313,  -313,   299,  -313,  -313,   562,
     336,   819,  -313,   323,  -313,   296,   819,   819,   351,  -313,
     914,  -313,  -313,  -313,  -313,  -313,  -313,   372,   344,   161,
     296,   346,   404,  -313,   372,  -313,  -313,  -313,   353,   819,
     356,   404,  -313,   372,   372,  -313,   175,  -313,   819,   357,
     381,  -313,   372,   339,   372,   296,  -313,   819,  -313,  -313,
    -313,  -313,   373,   372,   296,  -313,  -313,  -313,   374,   372,
     372,  -313,  -313,  -313,   372,  -313
};

  /* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
     Performed when YYTABLE does not specify something else to do.  Zero
     means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       0,   100,    86,    87,    90,    91,    92,    93,    96,    97,
      94,    95,    88,    89,   113,   114,     0,   102,   106,   104,
       0,   246,   121,    98,    99,     0,   243,   245,   136,   137,
     101,   105,   103,   143,     0,   153,   111,   109,     0,   155,
       0,   108,   120,     0,     1,   244,   137,     0,     0,     0,
     151,   152,     0,   112,   159,     0,   154,     0,     0,   251,
       0,   247,   116,     0,     0,   132,   139,   142,   138,   144,
     150,   110,   108,   162,   148,     0,     0,     0,     2,    10,
       7,     6,     9,     8,     0,     0,     0,     0,   145,    30,
      31,    32,    33,    34,    35,    11,     3,     4,    24,    36,
       0,    38,    42,    45,    48,    53,    56,    58,    60,    62,
      64,    66,    85,     0,     0,    36,    70,   183,   107,   209,
     250,   252,     0,     0,     0,   118,   125,   123,     0,   130,
       0,   134,   139,   133,     0,     0,   147,     0,   158,   160,
     149,     0,     0,    28,     0,    25,    26,    83,     0,   165,
       0,     0,    17,    18,     0,     0,     0,    27,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    69,    69,     0,   146,     0,     0,
     182,     0,   185,     0,    73,    74,    75,    76,    77,    78,
      79,    80,    81,    82,    72,     0,   207,   248,     0,   119,
     124,   122,   128,     0,   126,   115,   131,   135,   140,   141,
     161,   159,     0,   167,   156,   157,   168,   163,     0,     0,
       5,     0,   159,   167,   164,     0,    16,    13,     0,    22,
       0,    15,    39,    40,    41,    43,    44,    46,    47,    51,
      52,    49,    50,    54,    55,    57,    59,    61,     0,     0,
       0,     0,   179,   184,   180,     0,    71,   206,     0,   117,
       0,   129,   174,     0,     0,   170,     0,   166,   159,     0,
      29,     0,    84,     0,    37,    14,     0,    12,    63,    65,
      67,   178,   181,     0,   187,     2,     0,   198,     0,   216,
       0,   224,     0,     0,     0,     0,     0,   210,     0,   201,
     202,   188,   203,   204,   189,   190,   191,   192,   193,   127,
     175,   169,   171,   176,     0,   172,     0,    21,    23,     0,
     186,     0,   195,     0,     0,     0,   221,     0,   234,     0,
     239,   240,   241,     0,   211,   208,     0,   177,   173,    20,
       0,     0,   194,     0,   199,   220,     0,     0,     0,   235,
       0,   238,   242,   205,    19,    68,   196,     0,     0,     0,
     220,     0,     0,   235,     0,   200,   219,   217,     0,     0,
     236,     0,   197,     0,     0,   222,     0,   226,     0,   236,
     215,   218,     0,     0,     0,   237,   230,     0,   212,   223,
     225,   227,     0,     0,   237,   213,   228,   231,     0,     0,
       0,   232,   214,   229,     0,   233
};

  /* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -313,  -313,  -313,  -313,  -313,  -313,  -313,   -53,  -313,   -93,
     111,   112,    80,   108,   262,   264,   266,   198,   201,  -313,
     -51,  -313,   263,   -52,  -313,   -86,  -123,  -313,     7,    81,
      10,   395,  -313,   -41,  -313,  -313,  -313,   387,    88,  -313,
    -121,   328,  -313,   406,  -313,  -313,   319,   -37,   -10,    -7,
     325,   -48,  -313,  -313,     6,   -95,  -160,  -247,   -46,   181,
    -130,  -313,  -313,  -313,  -313,  -313,   127,  -313,  -313,   -21,
    -313,  -313,  -312,  -313,  -313,  -313,  -313,  -313,  -313,  -299,
    -313,  -313,  -313,  -313,  -313,  -313,  -313,  -313,  -313,   102,
      87,    73,  -313,  -313,   443,  -313,  -313,  -313,  -313
};

  /* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,    95,    96,    97,    98,   340,   228,   115,   100,   101,
     102,   103,   104,   105,   106,   107,   108,   109,   110,   111,
     116,   319,   248,   147,   195,   298,   113,    17,    18,    19,
      58,    37,    38,    21,    22,    23,   123,    43,   128,   203,
     129,   130,    24,    47,    48,   134,    68,    39,    40,    49,
     139,   263,    76,    77,   150,   264,   216,   181,   182,   183,
     300,   301,   343,   364,   323,   357,   302,   303,   336,   304,
     258,   196,   305,   306,   395,   399,   325,   374,   373,   176,
     307,   347,   382,   327,   384,   400,   393,   404,   350,   362,
     378,   392,   308,    25,    26,    27,   122,    60,    61
};

  /* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
     positive, shift that token.  If negative, reduce the rule whose
     number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      59,   148,    99,    56,   112,   117,    75,   157,   283,   206,
      20,   118,   209,    41,    33,    33,   349,    33,    33,    33,
     121,    33,    12,    65,    66,    51,    28,    30,    31,    32,
      42,   143,   145,   146,    33,    20,    52,   165,   166,   120,
      70,   260,    50,   215,   175,    72,   358,    99,    46,    35,
     370,    72,    53,   267,   224,   251,   148,   261,   148,   379,
      62,   368,   117,   267,    73,   232,   233,   234,    63,   230,
     126,   211,    34,   212,    34,    34,    34,   206,   211,   262,
     212,    35,    99,    35,   112,    35,   138,    35,    29,   266,
     136,   211,   283,   212,   126,    36,   137,   202,   167,   168,
      35,   197,   229,    67,  -220,    99,    99,    99,    99,    99,
      99,    99,    99,    99,    99,    99,    99,    99,    99,    99,
      99,   204,    74,    69,    54,    99,    55,   112,   213,   117,
     126,   214,   274,   126,   126,   253,   221,   126,   221,   223,
     151,   152,   153,   256,   127,    35,   316,   138,   218,   126,
     219,   126,   334,   222,   352,   212,   222,   262,   212,    99,
     140,   112,    35,   322,   280,    35,   141,   220,   127,   272,
     277,   275,    99,   221,   221,   149,    56,   276,   184,   185,
     186,   187,   188,   189,   190,   191,   192,   193,   131,   132,
     154,   342,   155,   158,   156,    99,    99,   348,   159,   160,
     310,   213,   119,   117,   127,   126,   137,   127,   127,   284,
     333,   127,   223,   337,   200,   201,    99,   299,   112,   137,
     314,   117,   367,   127,   318,   127,  -121,   365,   221,   133,
     149,   117,   149,    99,   372,   112,   383,   320,   345,   194,
     161,   162,   221,   380,   381,   239,   240,   241,   242,   268,
     135,   269,   389,   309,   391,   222,    57,   212,   163,   164,
     359,   360,   171,   397,   169,   170,   254,   255,   172,   402,
     403,   173,   235,   236,   405,   237,   238,   243,   244,   127,
     174,    44,   177,   376,   199,   217,   207,   117,    99,   225,
     355,   226,   385,   284,   231,   299,   250,   252,   257,   270,
     271,   394,   285,    79,    80,    81,    82,    83,    84,   363,
      85,    86,     1,     2,     3,     4,     5,     6,     7,     8,
       9,    10,    11,    12,    13,    14,    15,    16,   281,   311,
       1,     2,     3,     4,     5,     6,     7,     8,     9,    10,
      11,    12,    13,    14,    15,    16,   286,   287,   288,   312,
     289,   290,   291,   292,   293,   294,   295,   296,   313,    87,
     273,   321,   324,   221,   119,   326,   328,    89,    90,    91,
      92,    93,    94,   329,   335,   285,    79,    80,    81,    82,
      83,    84,   297,    85,    86,   338,   330,   331,   339,   346,
     341,    78,    79,    80,    81,    82,    83,    84,   344,    85,
      86,   351,   354,   361,   356,   366,   369,    78,    79,    80,
      81,    82,    83,    84,   375,    85,    86,   377,   386,   286,
     287,   288,   390,   289,   290,   291,   292,   293,   294,   295,
     296,   388,    87,   245,   396,   401,   246,   119,   249,   247,
      89,    90,    91,    92,    93,    94,   278,    71,    87,   124,
     279,   198,    64,   208,   317,   297,    89,    90,    91,    92,
      93,    94,   210,   353,    87,   371,   387,   398,    45,     0,
       0,   332,    89,    90,    91,    92,    93,    94,     0,     0,
      78,    79,    80,    81,    82,    83,    84,   297,    85,    86,
       0,     0,     0,     0,    78,    79,    80,    81,    82,    83,
      84,     0,    85,    86,     0,     0,     0,     0,     1,     0,
       0,     4,     5,     6,     7,     8,     9,    10,    11,    12,
      13,    14,    15,    16,    78,    79,    80,    81,    82,    83,
      84,     0,    85,    86,     0,     0,     0,    87,     0,     0,
       0,     0,     0,     0,     0,    89,    90,    91,    92,    93,
      94,    87,     0,   178,     0,   179,   114,   180,     0,    89,
      90,    91,    92,    93,    94,    78,    79,    80,    81,    82,
      83,    84,     0,    85,    86,     0,     0,     0,     0,     0,
       0,    87,     0,   178,     0,   179,   114,   282,     0,    89,
      90,    91,    92,    93,    94,    78,    79,    80,    81,    82,
      83,    84,     0,    85,    86,     0,     0,     0,     0,    78,
      79,    80,    81,    82,    83,    84,     0,    85,    86,     0,
       0,     0,    87,     0,   178,     0,   179,   114,     0,     0,
      89,    90,    91,    92,    93,    94,    78,    79,    80,    81,
      82,    83,    84,     0,    85,    86,     0,     0,     0,     0,
       0,     0,    87,     0,     0,    88,     0,     0,     0,     0,
      89,    90,    91,    92,    93,    94,    87,     0,     0,     0,
       0,   114,     0,     0,    89,    90,    91,    92,    93,    94,
      78,    79,    80,    81,    82,    83,    84,     0,    85,    86,
       0,     0,     0,    87,   227,     0,     0,     0,     0,     0,
       0,    89,    90,    91,    92,    93,    94,    78,    79,    80,
      81,    82,    83,    84,     0,    85,    86,     0,     0,     0,
       0,    78,    79,    80,    81,    82,    83,    84,     0,    85,
      86,     0,     0,     0,     0,     0,     0,    87,     0,     0,
     265,     0,     0,     0,     0,    89,    90,    91,    92,    93,
      94,    78,    79,    80,    81,    82,    83,    84,     0,    85,
      86,     0,     0,     0,    87,     0,     0,     0,     0,   273,
       0,     0,    89,    90,    91,    92,    93,    94,    87,     0,
       0,   315,     0,     0,     0,     0,    89,    90,    91,    92,
      93,    94,    78,    79,    80,    81,    82,    83,    84,     0,
      85,    86,     0,     0,     0,     0,     0,     0,   142,     0,
       0,     0,     0,     0,     0,     0,    89,    90,    91,    92,
      93,    94,    78,    79,    80,    81,    82,    83,    84,     0,
      85,    86,     1,     2,     3,     4,     5,     6,     7,     8,
       9,    10,    11,    12,    13,    14,    15,    16,     0,   144,
       0,     0,     0,     0,     0,     0,     0,    89,    90,    91,
      92,    93,    94,     0,     0,     0,  -249,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    87,
       0,     0,     0,    57,     0,     0,     0,    89,    90,    91,
      92,    93,    94,     1,     0,     0,     4,     5,     6,     7,
       8,     9,    10,    11,    12,    13,    14,    15,    16,     1,
       0,     0,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    16,     0,     1,     0,   125,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,     0,     0,   205,     1,     2,     3,     4,     5,
       6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
      16,   259,     1,     0,     0,     4,     5,     6,     7,     8,
       9,    10,    11,    12,    13,    14,    15,    16
};

static const yytype_int16 yycheck[] =
{
      41,    87,    55,    40,    55,    57,    54,   100,   255,   130,
       0,    57,   135,    20,     3,     3,   328,     3,     3,     3,
      61,     3,    42,    66,    67,    35,     3,    17,    18,    19,
       3,    84,    85,    86,     3,    25,    67,    15,    16,    60,
      50,    67,    35,   138,    20,    52,   345,   100,    65,    69,
     362,    58,    83,   213,   149,   178,   142,    83,   144,   371,
      65,   360,   114,   223,     3,   158,   159,   160,    65,   155,
      63,    60,    60,    62,    60,    60,    60,   198,    60,    61,
      62,    69,   135,    69,   135,    69,    76,    69,    65,   212,
      61,    60,   339,    62,    87,    83,    67,    83,    76,    77,
      69,   122,   154,     3,    80,   158,   159,   160,   161,   162,
     163,   164,   165,   166,   167,   168,   169,   170,   171,   172,
     173,   128,    61,    61,    60,   178,    62,   178,   138,   181,
     123,   138,   225,   126,   127,   181,    67,   130,    67,   149,
      10,    11,    12,   195,    63,    69,   269,   137,   142,   142,
     144,   144,    83,    60,    83,    62,    60,    61,    62,   212,
      61,   212,    69,   286,   250,    69,    67,    61,    87,   221,
      63,    61,   225,    67,    67,    87,   213,    67,    21,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    66,    67,
      60,   321,    62,    69,    64,   248,   249,   327,    74,    75,
      61,   211,    65,   255,   123,   198,    67,   126,   127,   255,
     296,   130,   222,    61,   126,   127,   269,   258,   269,    67,
     268,   273,    61,   142,   276,   144,    66,   357,    67,    66,
     142,   283,   144,   286,   364,   286,    61,   283,   324,    82,
      70,    71,    67,   373,   374,   165,   166,   167,   168,    60,
      82,    62,   382,   260,   384,    60,    82,    62,    13,    14,
     346,   347,    68,   393,    17,    18,    66,    67,    78,   399,
     400,    79,   161,   162,   404,   163,   164,   169,   170,   198,
      19,     0,    63,   369,    66,     3,    66,   339,   341,    61,
     341,     3,   378,   339,     3,   336,    80,     3,    66,    61,
      61,   387,     3,     4,     5,     6,     7,     8,     9,   350,
      11,    12,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    63,    61,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    49,    63,
      51,    52,    53,    54,    55,    56,    57,    58,    61,    60,
      65,    81,    60,    67,    65,    60,    60,    68,    69,    70,
      71,    72,    73,     3,    66,     3,     4,     5,     6,     7,
       8,     9,    83,    11,    12,    63,    83,    83,    67,    60,
      81,     3,     4,     5,     6,     7,     8,     9,    81,    11,
      12,    83,    66,    52,    81,    61,    60,     3,     4,     5,
       6,     7,     8,     9,    61,    11,    12,    61,    61,    47,
      48,    49,    83,    51,    52,    53,    54,    55,    56,    57,
      58,    50,    60,   171,    61,    61,   172,    65,   175,   173,
      68,    69,    70,    71,    72,    73,   248,    52,    60,    62,
     249,   123,    46,   134,   273,    83,    68,    69,    70,    71,
      72,    73,   137,   336,    60,   363,   379,   394,    25,    -1,
      -1,    83,    68,    69,    70,    71,    72,    73,    -1,    -1,
       3,     4,     5,     6,     7,     8,     9,    83,    11,    12,
      -1,    -1,    -1,    -1,     3,     4,     5,     6,     7,     8,
       9,    -1,    11,    12,    -1,    -1,    -1,    -1,    31,    -1,
      -1,    34,    35,    36,    37,    38,    39,    40,    41,    42,
      43,    44,    45,    46,     3,     4,     5,     6,     7,     8,
       9,    -1,    11,    12,    -1,    -1,    -1,    60,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    68,    69,    70,    71,    72,
      73,    60,    -1,    62,    -1,    64,    65,    66,    -1,    68,
      69,    70,    71,    72,    73,     3,     4,     5,     6,     7,
       8,     9,    -1,    11,    12,    -1,    -1,    -1,    -1,    -1,
      -1,    60,    -1,    62,    -1,    64,    65,    66,    -1,    68,
      69,    70,    71,    72,    73,     3,     4,     5,     6,     7,
       8,     9,    -1,    11,    12,    -1,    -1,    -1,    -1,     3,
       4,     5,     6,     7,     8,     9,    -1,    11,    12,    -1,
      -1,    -1,    60,    -1,    62,    -1,    64,    65,    -1,    -1,
      68,    69,    70,    71,    72,    73,     3,     4,     5,     6,
       7,     8,     9,    -1,    11,    12,    -1,    -1,    -1,    -1,
      -1,    -1,    60,    -1,    -1,    63,    -1,    -1,    -1,    -1,
      68,    69,    70,    71,    72,    73,    60,    -1,    -1,    -1,
      -1,    65,    -1,    -1,    68,    69,    70,    71,    72,    73,
       3,     4,     5,     6,     7,     8,     9,    -1,    11,    12,
      -1,    -1,    -1,    60,    61,    -1,    -1,    -1,    -1,    -1,
      -1,    68,    69,    70,    71,    72,    73,     3,     4,     5,
       6,     7,     8,     9,    -1,    11,    12,    -1,    -1,    -1,
      -1,     3,     4,     5,     6,     7,     8,     9,    -1,    11,
      12,    -1,    -1,    -1,    -1,    -1,    -1,    60,    -1,    -1,
      63,    -1,    -1,    -1,    -1,    68,    69,    70,    71,    72,
      73,     3,     4,     5,     6,     7,     8,     9,    -1,    11,
      12,    -1,    -1,    -1,    60,    -1,    -1,    -1,    -1,    65,
      -1,    -1,    68,    69,    70,    71,    72,    73,    60,    -1,
      -1,    63,    -1,    -1,    -1,    -1,    68,    69,    70,    71,
      72,    73,     3,     4,     5,     6,     7,     8,     9,    -1,
      11,    12,    -1,    -1,    -1,    -1,    -1,    -1,    60,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    68,    69,    70,    71,
      72,    73,     3,     4,     5,     6,     7,     8,     9,    -1,
      11,    12,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    -1,    60,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    68,    69,    70,
      71,    72,    73,    -1,    -1,    -1,    65,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    60,
      -1,    -1,    -1,    82,    -1,    -1,    -1,    68,    69,    70,
      71,    72,    73,    31,    -1,    -1,    34,    35,    36,    37,
      38,    39,    40,    41,    42,    43,    44,    45,    46,    31,
      -1,    -1,    34,    35,    36,    37,    38,    39,    40,    41,
      42,    43,    44,    45,    46,    -1,    31,    -1,    66,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    -1,    -1,    66,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
      46,    66,    31,    -1,    -1,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,    46
};

  /* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
     symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    41,    42,    43,    44,    45,    46,   111,   112,   113,
     114,   117,   118,   119,   126,   177,   178,   179,     3,    65,
     114,   114,   114,     3,    60,    69,    83,   115,   116,   131,
     132,   133,     3,   121,     0,   178,    65,   127,   128,   133,
     112,   132,    67,    83,    60,    62,   131,    82,   114,   117,
     181,   182,    65,    65,   127,    66,    67,     3,   130,    61,
     132,   115,   133,     3,    61,   135,   136,   137,     3,     4,
       5,     6,     7,     8,     9,    11,    12,    60,    63,    68,
      69,    70,    71,    72,    73,    85,    86,    87,    88,    91,
      92,    93,    94,    95,    96,    97,    98,    99,   100,   101,
     102,   103,   104,   110,    65,    91,   104,   107,   142,    65,
     153,   117,   180,   120,   121,    66,   112,   113,   122,   124,
     125,    66,    67,    66,   129,    82,    61,    67,   114,   134,
      61,    67,    60,    91,    60,    91,    91,   107,   109,   122,
     138,    10,    11,    12,    60,    62,    64,    93,    69,    74,
      75,    70,    71,    13,    14,    15,    16,    76,    77,    17,
      18,    68,    78,    79,    19,    20,   163,    63,    62,    64,
      66,   141,   142,   143,    21,    22,    23,    24,    25,    26,
      27,    28,    29,    30,    82,   108,   155,   153,   125,    66,
     122,   122,    83,   123,   133,    66,   124,    66,   130,   110,
     134,    60,    62,   132,   133,   139,   140,     3,   138,   138,
      61,    67,    60,   132,   139,    61,     3,    61,    90,   107,
     109,     3,    93,    93,    93,    94,    94,    95,    95,    96,
      96,    96,    96,    97,    97,    98,    99,   100,   106,   106,
      80,   110,     3,   142,    66,    67,   107,    66,   154,    66,
      67,    83,    61,   135,   139,    63,   110,   140,    60,    62,
      61,    61,   107,    65,    93,    61,    67,    63,   101,   102,
     109,    63,    66,   141,   142,     3,    47,    48,    49,    51,
      52,    53,    54,    55,    56,    57,    58,    83,   109,   117,
     144,   145,   150,   151,   153,   156,   157,   164,   176,   133,
      61,    61,    63,    61,   135,    63,   110,   143,   107,   105,
     142,    81,   110,   148,    60,   160,    60,   167,    60,     3,
      83,    83,    83,   109,    83,    66,   152,    61,    63,    67,
      89,    81,   144,   146,    81,   109,    60,   165,   144,   156,
     172,    83,    83,   150,    66,   104,    81,   149,   163,   109,
     109,    52,   173,   117,   147,   144,    61,    61,   163,    60,
     156,   173,   144,   162,   161,    61,   109,    61,   174,   156,
     144,   144,   166,    61,   168,   109,    61,   174,    50,   144,
      83,   144,   175,   170,   109,   158,    61,   144,   175,   159,
     169,    61,   144,   144,   171,   144
};

  /* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    84,    85,    85,    85,    85,    86,    86,    86,    86,
      87,    88,    88,    88,    88,    88,    88,    88,    88,    88,
      89,    89,    90,    90,    91,    91,    91,    91,    91,    91,
      92,    92,    92,    92,    92,    92,    93,    93,    94,    94,
      94,    94,    95,    95,    95,    96,    96,    96,    97,    97,
      97,    97,    97,    98,    98,    98,    99,    99,   100,   100,
     101,   101,   102,   102,   103,   103,   104,   105,   104,   106,
     107,   107,   108,   108,   108,   108,   108,   108,   108,   108,
     108,   108,   108,   109,   109,   110,   111,   111,   112,   113,
     113,   113,   113,   113,   113,   113,   113,   113,   113,   113,
     113,   114,   114,   114,   114,   114,   114,   115,   115,   116,
     116,   117,   117,   118,   118,   119,   120,   119,   119,   119,
     119,   121,   122,   122,   122,   122,   123,   123,   124,   124,
     125,   125,   126,   126,   126,   126,   126,   128,   127,   129,
     127,   130,   130,   131,   131,   131,   131,   131,   131,   131,
     132,   132,   132,   132,   133,   133,   134,   134,   134,   136,
     135,   135,   137,   137,   138,   138,   139,   139,   139,   140,
     140,   140,   140,   140,   140,   140,   140,   140,   141,   141,
     142,   142,   142,   142,   143,   143,   143,   143,   144,   144,
     144,   144,   144,   144,   145,   146,   147,   145,   148,   149,
     145,   150,   150,   151,   152,   151,   153,   154,   153,   155,
     156,   156,   158,   159,   157,   157,   160,   161,   157,   162,
     163,   165,   166,   164,   167,   164,   168,   164,   169,   164,
     170,   164,   171,   164,   172,   173,   174,   175,   176,   176,
     176,   176,   176,   177,   177,   178,   178,   180,   179,   181,
     179,   182,   182
};

  /* YYR2[YYN] -- Number of symbols on the right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     1,     1,     1,     3,     1,     1,     1,     1,
       1,     1,     4,     3,     4,     3,     3,     2,     2,     7,
       1,     0,     1,     3,     1,     2,     2,     2,     2,     4,
       1,     1,     1,     1,     1,     1,     1,     4,     1,     3,
       3,     3,     1,     3,     3,     1,     3,     3,     1,     3,
       3,     3,     3,     1,     3,     3,     1,     3,     1,     3,
       1,     3,     1,     4,     1,     4,     1,     0,     7,     0,
       1,     3,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     3,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     2,     1,     2,     1,     2,     1,     3,     1,     1,
       3,     2,     3,     1,     1,     5,     0,     6,     4,     5,
       2,     0,     2,     1,     2,     1,     1,     3,     2,     3,
       1,     2,     4,     5,     5,     6,     2,     0,     2,     0,
       4,     3,     1,     1,     3,     3,     4,     4,     3,     4,
       3,     2,     2,     1,     2,     1,     2,     2,     1,     0,
       2,     3,     1,     3,     2,     1,     2,     1,     1,     3,
       2,     3,     3,     4,     2,     3,     3,     4,     3,     2,
       3,     4,     2,     1,     2,     1,     4,     3,     1,     1,
       1,     1,     1,     1,     3,     0,     0,     6,     0,     0,
       5,     1,     1,     1,     0,     3,     3,     0,     5,     0,
       1,     2,     0,     0,    11,     7,     0,     0,     7,     0,
       0,     0,     0,     8,     0,     8,     0,     8,     0,    11,
       0,     9,     0,    12,     0,     0,     0,     0,     3,     2,
       2,     2,     3,     1,     2,     1,     1,     0,     5,     0,
       4,     1,     2
};


#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)
#define YYEMPTY         (-2)
#define YYEOF           0

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                  \
do                                                              \
  if (yychar == YYEMPTY)                                        \
    {                                                           \
      yychar = (Token);                                         \
      yylval = (Value);                                         \
      YYPOPSTACK (yylen);                                       \
      yystate = *yyssp;                                         \
      goto yybackup;                                            \
    }                                                           \
  else                                                          \
    {                                                           \
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;                                                  \
    }                                                           \
while (0)

/* Error token number */
#define YYTERROR        1
#define YYERRCODE       256



/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)

/* This macro is provided for backward compatibility. */
#ifndef YY_LOCATION_PRINT
# define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#endif


# define YY_SYMBOL_PRINT(Title, Type, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Type, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*----------------------------------------.
| Print this symbol's value on YYOUTPUT.  |
`----------------------------------------*/

static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  FILE *yyo = yyoutput;
  YYUSE (yyo);
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
  YYUSE (yytype);
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyoutput, "%s %s (",
             yytype < YYNTOKENS ? "token" : "nterm", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yytype_int16 *yyssp, YYSTYPE *yyvsp, int yyrule)
{
  unsigned long int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       yystos[yyssp[yyi + 1 - yynrhs]],
                       &(yyvsp[(yyi + 1) - (yynrhs)])
                                              );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
yystrlen (const char *yystr)
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            /* Fall through.  */
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return 1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return 2 if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYSIZE_T *yymsg_alloc, char **yymsg,
                yytype_int16 *yyssp, int yytoken)
{
  YYSIZE_T yysize0 = yytnamerr (YY_NULLPTR, yytname[yytoken]);
  YYSIZE_T yysize = yysize0;
  enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat. */
  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
  /* Number of reported tokens (one for the "unexpected", one per
     "expected"). */
  int yycount = 0;

  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yytoken != YYEMPTY)
    {
      int yyn = yypact[*yyssp];
      yyarg[yycount++] = yytname[yytoken];
      if (!yypact_value_is_default (yyn))
        {
          /* Start YYX at -YYN if negative to avoid negative indexes in
             YYCHECK.  In other words, skip the first -YYN actions for
             this state because they are default actions.  */
          int yyxbegin = yyn < 0 ? -yyn : 0;
          /* Stay within bounds of both yycheck and yytname.  */
          int yychecklim = YYLAST - yyn + 1;
          int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
          int yyx;

          for (yyx = yyxbegin; yyx < yyxend; ++yyx)
            if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR
                && !yytable_value_is_error (yytable[yyx + yyn]))
              {
                if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                  {
                    yycount = 1;
                    yysize = yysize0;
                    break;
                  }
                yyarg[yycount++] = yytname[yyx];
                {
                  YYSIZE_T yysize1 = yysize + yytnamerr (YY_NULLPTR, yytname[yyx]);
                  if (! (yysize <= yysize1
                         && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
                    return 2;
                  yysize = yysize1;
                }
              }
        }
    }

  switch (yycount)
    {
# define YYCASE_(N, S)                      \
      case N:                               \
        yyformat = S;                       \
      break
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
# undef YYCASE_
    }

  {
    YYSIZE_T yysize1 = yysize + yystrlen (yyformat);
    if (! (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
      return 2;
    yysize = yysize1;
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return 1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yyarg[yyi++]);
          yyformat += 2;
        }
      else
        {
          yyp++;
          yyformat++;
        }
  }
  return 0;
}
#endif /* YYERROR_VERBOSE */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
{
  YYUSE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YYUSE (yytype);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}




/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;


/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       'yyss': related to states.
       'yyvs': related to semantic values.

       Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yyssp = yyss = yyssa;
  yyvsp = yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */
  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        YYSTYPE *yyvs1 = yyvs;
        yytype_int16 *yyss1 = yyss;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * sizeof (*yyssp),
                    &yyvs1, yysize * sizeof (*yyvsp),
                    &yystacksize);

        yyss = yyss1;
        yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yytype_int16 *yyss1 = yyss;
        union yyalloc *yyptr =
          (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
        if (! yyptr)
          goto yyexhaustedlab;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
                  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 134 "MiniC.y" /* yacc.c:1646  */
    {
            int symbol_type;
            void *sym_ptr;
            sym_ptr = LookupSymbol((yyvsp[0].vstr),&symbol_type);
            if(symbol_type == 0)//啥都不是，返回错误
            {
                yyerror("Symbol hasn't been declared!");
            }
            else if(symbol_type == IDENTIFIER)//没有其他可能了，不可能是enum_constant或者type,在lex时就被筛过了
            {
				Identifier_t *id = (Identifier_t *)sym_ptr;
                (yyval.expression_s).isConst = id -> isConst;
				//#warning "The IDENTIFIER hasn't finished yet!"
				(yyval.expression_s).type = id -> type;
				//if($$.type -> type == idt_fpointer)
					//$$.lr_value = 1;
				(yyval.expression_s).lr_value = 0;
				(yyval.expression_s).addr = id -> TACname;
				(yyval.expression_s).laddr = NULL;
				if((yyval.expression_s).isConst)
					if(type_of_const_exp[(yyval.expression_s).type -> type])
						(yyval.expression_s).value.vint = id -> value.vint;
            }
        }
#line 1788 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 3:
#line 158 "MiniC.y" /* yacc.c:1646  */
    {
		(yyval.expression_s) = (yyvsp[0].expression_s);
	}
#line 1796 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 4:
#line 161 "MiniC.y" /* yacc.c:1646  */
    {
		(yyval.expression_s) = (yyvsp[0].expression_s);
	}
#line 1804 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 5:
#line 164 "MiniC.y" /* yacc.c:1646  */
    {
		(yyval.expression_s) = (yyvsp[-1].expression_s);
	}
#line 1812 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 6:
#line 170 "MiniC.y" /* yacc.c:1646  */
    {
		(yyval.expression_s).lr_value=1;
		(yyval.expression_s).isConst = 1;
		(yyval.expression_s).value.vint = (yyvsp[0].vint);
		(yyval.expression_s).addr = strdup(('t' + std::to_string(CreateTempVar())).c_str());
		(yyval.expression_s).laddr = NULL;
		(yyval.expression_s).type = (const_Typename_ptr)LookupSymbol("int", NULL);
		gen_const("int4",(yyval.expression_s).addr,&(yyvsp[0].vint));
	}
#line 1826 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 7:
#line 179 "MiniC.y" /* yacc.c:1646  */
    {
		(yyval.expression_s).lr_value = 1;
		(yyval.expression_s).isConst = 1;
		//$$.value.vchar = $1;
		(yyval.expression_s).addr = strdup(('t' + std::to_string(CreateTempVar())).c_str());
		(yyval.expression_s).laddr = NULL;
		(yyval.expression_s).type = (const_Typename_ptr)LookupSymbol("char", NULL);
		gen_const("int1",(yyval.expression_s).addr,&(yyvsp[0].vchar));
	}
#line 1840 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 8:
#line 188 "MiniC.y" /* yacc.c:1646  */
    {
		(yyval.expression_s).lr_value = 1;
		(yyval.expression_s).isConst = 1;
		//$$.value.vdouble = $1;
		(yyval.expression_s).addr = strdup(('t' + std::to_string(CreateTempVar())).c_str());
		(yyval.expression_s).laddr = NULL;
		(yyval.expression_s).type = (const_Typename_ptr)LookupSymbol("double", NULL);
		gen_const("float8",(yyval.expression_s).addr,&(yyvsp[0].vdouble)); //应该翻译成三地址码中的double!
	}
#line 1854 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 9:
#line 197 "MiniC.y" /* yacc.c:1646  */
    {
		(yyval.expression_s).lr_value = 1;
		(yyval.expression_s).isConst = 1;
		(yyval.expression_s).value.vint = (yyvsp[0].vint);
		(yyval.expression_s).addr = strdup(('t' + std::to_string(CreateTempVar())).c_str());
		(yyval.expression_s).laddr = NULL;
		(yyval.expression_s).type = (const_Typename_ptr)LookupSymbol("int", NULL);
		gen_const("int4",(yyval.expression_s).addr,&(yyvsp[0].vint));
	}
#line 1868 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 10:
#line 209 "MiniC.y" /* yacc.c:1646  */
    {
				//$$.value.vstr = $1;
				(yyval.expression_s).lr_value = 1;
				(yyval.expression_s).addr = strdup(('t' + std::to_string(CreateTempVar())).c_str());
				(yyval.expression_s).laddr = NULL;
				(yyval.expression_s).isConst = 1;			
				Typename_t *tmp_type = new Typename_t;
				tmp_type -> type = idt_array;
				tmp_type -> name = NULL;
				tmp_type -> isConst = 1;
				tmp_type -> size = strlen((yyvsp[0].vstr)) + 1;
				tmp_type -> structure = new IdStructure_t;
				tmp_type -> structure -> pointer.rbase_type = (const_Typename_ptr)LookupSymbol("char", NULL);
				tmp_type -> structure -> pointer.base_type = (const_Typename_ptr)LookupSymbol("char", NULL);
				tmp_type -> structure -> pointer.length = strlen((yyvsp[0].vstr)) + 1;
				(yyval.expression_s).type = tmp_type;
				gen_const("str",(yyval.expression_s).addr,(yyvsp[0].vstr));
			}
#line 1891 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 11:
#line 230 "MiniC.y" /* yacc.c:1646  */
    {
		  (yyval.expression_s) = (yyvsp[0].expression_s);
	  }
#line 1899 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 12:
#line 233 "MiniC.y" /* yacc.c:1646  */
    {
		if((yyvsp[-1].expression_s).type -> type < 8) //下标必须是整数
		{
			if((yyvsp[-3].expression_s).type -> type == idt_array || (yyvsp[-3].expression_s).type -> type == idt_pointer)
			{
				char *tmp_name1, *tmp_name2, *tmp_name3;
				//直接利用如下函数
				tmp_name1 = get_cast_name(idt_int, (yyvsp[-1].expression_s).type -> type, (yyvsp[-1].expression_s).get_addr());
				
				const_Typename_ptr b_type = (yyvsp[-3].expression_s).type -> structure -> pointer . base_type;
				
				tmp_name2 = sizeof_type(b_type);
				tmp_name3 = get_TAC_name('t',CreateTempVar());
				gen_var("int4", tmp_name3);
				//gen_cpy(tmp_name3, tmp_name2); //这么一大坨终于得到该指针这一维的大小了。。。

				gen_op2(tmp_name3,tmp_name2,tmp_name1,"*");
				char *pf = (yyvsp[-3].expression_s).get_addr();

				char *rel_loc = get_TAC_name('t',CreateTempVar());
				gen_var("ptr", rel_loc);
				gen_op2(rel_loc, pf, tmp_name3,"+");

				(yyval.expression_s).type = b_type;
				if((yyval.expression_s).type -> type == idt_array || check_str_un((yyval.expression_s)))//数组和struct非常奇葩，它们的位置实际上就是他们的值，要特判一下
				{
					(yyval.expression_s).addr = rel_loc;
					(yyval.expression_s).laddr = NULL;
				}
				else
				{
					(yyval.expression_s).addr = NULL;
					(yyval.expression_s).laddr = rel_loc;
				}
				if((yyval.expression_s).type -> type == idt_array) //假如这是个数组，则不能修改，是个右值
					(yyval.expression_s).lr_value = 1;
				else	
					(yyval.expression_s).lr_value = 0;
				(yyval.expression_s).isConst = 0; //只要是这种带指针的统统不算常量表达式
			}
			else
			{
				debug((yyvsp[-3].expression_s).type->type);
				yyerror("only the pointer or array can use [] operator !");
			}
		}
		else yyerror("The subscript must be integer!");

	}
#line 1953 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 13:
#line 282 "MiniC.y" /* yacc.c:1646  */
    {
		argument_expression_list_s_t tmp = new Argument_Expression_List_s_t;
		tmp->length = 0;
		tmp->next = tmp;
		(yyval.expression_s) = get_function((yyvsp[-2].expression_s), tmp);
	}
#line 1964 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 14:
#line 288 "MiniC.y" /* yacc.c:1646  */
    {
		(yyval.expression_s) = get_function((yyvsp[-3].expression_s), (yyvsp[-1].argument_expression_list_s)->next);
	}
#line 1972 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 15:
#line 291 "MiniC.y" /* yacc.c:1646  */
    {
		if ((yyval.expression_s).type->type == idt_struct || (yyval.expression_s).type->type == idt_union) //struct or union
		{
			int flag = 0;
			for (SymbolList_t *i = (yyval.expression_s).type->structure->record; i != NULL; i = i->next)
				if(strcmp((yyvsp[0].vstr), i -> id -> name) == 0)
				{
					(yyval.expression_s) = __make_exp((yyvsp[-2].expression_s).addr, i->offset, i->id->type);
					flag = 1;
					break;
				}
			if(flag == 0)
				yyerror("this struct didn't have this identifier");
		}
		else yyerror("only struct/union can use '.' operator");
	}
#line 1993 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 16:
#line 307 "MiniC.y" /* yacc.c:1646  */
    {
		if (((yyval.expression_s).type -> type == idt_pointer || (yyval.expression_s).type -> type == idt_array) && check_str_un((yyval.expression_s).type->structure->pointer.base_type -> type))
		{
			expression_s_t This;
			This.type = (yyval.expression_s).type->structure->pointer.base_type;
			This.lr_value = 1;
			This.isConst = 0;
			This.addr = (yyvsp[-2].expression_s).get_addr();
			This.laddr = NULL;
			int flag = 0;
			for (SymbolList_t *i = This.type->structure->record; i != NULL; i = i->next)
				if(strcmp((yyvsp[0].vstr), i -> id -> name) == 0)
				{
					(yyval.expression_s) = __make_exp(This.addr, i->offset, i->id->type);
					flag = 1;
					break;
				}
			if(flag == 0)
				yyerror("this struct didn't have this identifier");
		}
		else yyerror("only pointer of struct/union can use operator ->");
	}
#line 2020 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 17:
#line 330 "MiniC.y" /* yacc.c:1646  */
    {
		postfix_expression_INC_DEC_OP((yyval.expression_s),(yyvsp[-1].expression_s),"+");
	}
#line 2028 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 18:
#line 333 "MiniC.y" /* yacc.c:1646  */
    {
		postfix_expression_INC_DEC_OP((yyval.expression_s),(yyvsp[-1].expression_s),"-");
	}
#line 2036 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 19:
#line 336 "MiniC.y" /* yacc.c:1646  */
    {
            initializer_s_t *tmp = new initializer_s_t;
            tmp->data.addr = tmp->data.laddr = NULL;
            tmp->lst = (yyvsp[-2].initializer_list_s);
            int tv = CreateTempVar();
            char *TACname = strdup(('t' + std::to_string(tv)).c_str());
            genDeclare((yyvsp[-5].type_name_s), TACname, false);
            genInitilize((yyvsp[-5].type_name_s), TACname, tmp);
            freeInit(tmp);
            (yyval.expression_s).isConst = 1;
            (yyval.expression_s).type = (yyvsp[-5].type_name_s);
            (yyval.expression_s).addr = TACname;
            (yyval.expression_s).laddr = NULL;
            (yyval.expression_s).lr_value = 1;
        }
#line 2056 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 22:
#line 359 "MiniC.y" /* yacc.c:1646  */
    {
		  (yyval.argument_expression_list_s) = new Argument_Expression_List_s_t;
		  (yyval.argument_expression_list_s)->now_exp = (yyvsp[0].expression_s);
		  (yyval.argument_expression_list_s)->length = 1;
		  (yyval.argument_expression_list_s)->next = (yyval.argument_expression_list_s);
	  }
#line 2067 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 23:
#line 365 "MiniC.y" /* yacc.c:1646  */
    {
		(yyval.argument_expression_list_s) = new Argument_Expression_List_s_t;
		(yyval.argument_expression_list_s)->now_exp = (yyvsp[0].expression_s);
		(yyvsp[-2].argument_expression_list_s)->next -> length ++;
		(yyval.argument_expression_list_s)->next = (yyvsp[-2].argument_expression_list_s)->next;
		(yyvsp[-2].argument_expression_list_s)->next = (yyval.argument_expression_list_s);
	}
#line 2079 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 24:
#line 375 "MiniC.y" /* yacc.c:1646  */
    {(yyval.expression_s) = (yyvsp[0].expression_s);}
#line 2085 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 25:
#line 376 "MiniC.y" /* yacc.c:1646  */
    {
		INC_DEC_OP_unary_expression((yyvsp[0].expression_s),"+");
		(yyval.expression_s) = (yyvsp[0].expression_s); //++i 应该传回的是i的引用
	}
#line 2094 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 26:
#line 380 "MiniC.y" /* yacc.c:1646  */
    {
		INC_DEC_OP_unary_expression((yyvsp[0].expression_s),"-");
		(yyval.expression_s) = (yyvsp[0].expression_s); //++i 应该传回的是i的引用
	}
#line 2103 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 27:
#line 384 "MiniC.y" /* yacc.c:1646  */
    {
		if((yyvsp[-1].vchar) == '&')
		{
			if((yyvsp[0].expression_s).lr_value == 1)
				yyerror("lvalue required as unary & operand");
			
			char *loc = get_TAC_name('t',CreateTempVar());
			gen_var("ptr",loc);
			if((yyvsp[0].expression_s).type -> type == idt_array || (yyvsp[0].expression_s).type -> type == idt_fpointer || check_str_un((yyvsp[0].expression_s))) //fpointer 也是奇葩的类型，取&也是直接取地址
				gen_cpy(loc, (yyvsp[0].expression_s).addr);
			else if((yyvsp[0].expression_s).addr == NULL)
				gen_cpy(loc, (yyvsp[0].expression_s).laddr);
			else
				gen_op1(loc, (yyvsp[0].expression_s).addr, "&");
            (yyval.expression_s).addr = loc;
            (yyval.expression_s).laddr = NULL;
			(yyval.expression_s).lr_value = 1;
			(yyval.expression_s).isConst = 0;
			Typename_t *tmp_type = new Typename_t;
			tmp_type -> type = idt_pointer;
			tmp_type -> name = NULL;
			tmp_type -> isConst = 0;
			tmp_type -> size = POINTER_SIZE;
			tmp_type -> structure = new IdStructure_t;
			tmp_type -> structure -> pointer.base_type = (yyvsp[0].expression_s).type;
			(yyval.expression_s).type = tmp_type;
		}
		if((yyvsp[-1].vchar) == '*')
		{
			//???对一个函数指针进行该操作会有啥用？
			if((yyvsp[0].expression_s).type -> type == idt_array || (yyvsp[0].expression_s).type -> type == idt_pointer)
			{
				const_Typename_ptr b_type = (yyvsp[0].expression_s).type -> structure -> pointer.base_type;
				char *now_loc = get_TAC_name('t',CreateTempVar());
				gen_var("ptr",now_loc);
				gen_cpy(now_loc, (yyvsp[0].expression_s).get_addr());
				(yyval.expression_s).type = b_type;
				if((yyval.expression_s).type -> type == idt_array || check_str_un((yyval.expression_s)))
				{
					(yyval.expression_s).addr = now_loc;
					(yyval.expression_s).laddr = NULL;
				}
				else
				{
					(yyval.expression_s).addr = NULL;
					(yyval.expression_s).laddr = now_loc;
				}
				(yyval.expression_s).lr_value = (b_type -> type) == idt_array ? 1 : 0;
				(yyval.expression_s).isConst = 0; //只要是这种带指针的统统不算常量表达式，是不是常量要看type.isConst!
			}
			else yyerror("only array or pointer can use * operator!");
		}
		if((yyvsp[-1].vchar) == '+')
		{
			if(!check_number((yyvsp[0].expression_s))) //只有数字能有这种操作！
				yyerror("wrong type argument on unary +");
			(yyval.expression_s).addr = (yyvsp[0].expression_s).addr;
			(yyval.expression_s).laddr = (yyvsp[0].expression_s).laddr;
			(yyval.expression_s).lr_value = 1;
			(yyval.expression_s).type = (yyvsp[0].expression_s).type;
			(yyval.expression_s).isConst = (yyvsp[0].expression_s).isConst;
			if((yyval.expression_s).isConst)
				(yyval.expression_s).value = (yyvsp[0].expression_s).value;
		}
		if((yyvsp[-1].vchar) == '-')
		{
			if(!check_number((yyvsp[0].expression_s))) //只有数字能有这种操作！
				yyerror("wrong type argument on unary -");
			(yyval.expression_s).addr = get_TAC_name('t',CreateTempVar());
			genDeclare((yyvsp[0].expression_s).type, (yyval.expression_s).addr, 0);
			gen_op1((yyval.expression_s).addr, (yyvsp[0].expression_s).get_addr(), "-");
			(yyval.expression_s).laddr = NULL;
			(yyval.expression_s).lr_value = 1;
			(yyval.expression_s).type = (yyvsp[0].expression_s).type;
			(yyval.expression_s).isConst = (yyvsp[0].expression_s).isConst;
			if((yyval.expression_s).isConst)
				(yyval.expression_s).value.vint = -(yyvsp[0].expression_s).value.vint;
		}
		if((yyvsp[-1].vchar) == '~')
		{
			if(!check_int((yyvsp[0].expression_s))) //只有整数能有这种操作！
				yyerror("wrong type argument on unary ~ (only integer can use '~')");
			(yyval.expression_s).addr = get_TAC_name('t',CreateTempVar());
			genDeclare((yyvsp[0].expression_s).type, (yyval.expression_s).addr, 0);
			gen_op1((yyval.expression_s).addr, (yyvsp[0].expression_s).get_addr(), "~");
			(yyval.expression_s).laddr = NULL;
			(yyval.expression_s).lr_value = 1;
			(yyval.expression_s).type = (yyvsp[0].expression_s).type;
			(yyval.expression_s).isConst = (yyvsp[0].expression_s).isConst;
			if((yyval.expression_s).isConst)
				(yyval.expression_s).value.vint = ~(yyvsp[0].expression_s).value.vint;
		}
		if((yyvsp[-1].vchar) == '!')
		{
			if(!check_int((yyvsp[0].expression_s))) //只有数字能有这种操作！
				yyerror("wrong type argument on unary !");
			(yyval.expression_s).addr = get_TAC_name('t',CreateTempVar());
			genDeclare((yyvsp[0].expression_s).type, (yyval.expression_s).addr, 0);
			gen_op1((yyval.expression_s).addr, (yyvsp[0].expression_s).get_addr(), "!");
			(yyval.expression_s).laddr = NULL;
			(yyval.expression_s).lr_value = 1;
			(yyval.expression_s).type = (yyvsp[0].expression_s).type;
			(yyval.expression_s).isConst = (yyvsp[0].expression_s).isConst;
			if((yyval.expression_s).isConst)
				(yyval.expression_s).value.vint = !(yyvsp[0].expression_s).value.vint;
		}
	}
#line 2215 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 28:
#line 491 "MiniC.y" /* yacc.c:1646  */
    {
		(yyval.expression_s).addr = get_TAC_name('t',CreateTempVar());
		gen_const("uint4", (yyval.expression_s).addr, &((yyvsp[0].expression_s).type -> size));
        (yyval.expression_s).laddr = NULL;
		(yyval.expression_s).type = (const_Typename_ptr)LookupSymbol("unsigned int", NULL);
		(yyval.expression_s).lr_value = 1;
		(yyval.expression_s).isConst = 1;
		//$$.value.vint = $2.type -> size; //unsigned int 不用维护
	}
#line 2229 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 29:
#line 500 "MiniC.y" /* yacc.c:1646  */
    {
		(yyval.expression_s).addr = get_TAC_name('t',CreateTempVar());
		gen_const("uint4", (yyval.expression_s).addr, &((yyvsp[-1].type_name_s) -> size));
        (yyval.expression_s).laddr = NULL;
		(yyval.expression_s).type = (const_Typename_ptr)LookupSymbol("unsigned int", NULL);
		(yyval.expression_s).lr_value = 1;
		(yyval.expression_s).isConst = 1;
		//$$.value.vint = $2.type -> size;
	}
#line 2243 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 30:
#line 512 "MiniC.y" /* yacc.c:1646  */
    {(yyval.vchar)='&';}
#line 2249 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 31:
#line 513 "MiniC.y" /* yacc.c:1646  */
    {(yyval.vchar)='*';}
#line 2255 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 32:
#line 514 "MiniC.y" /* yacc.c:1646  */
    {(yyval.vchar)='+';}
#line 2261 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 33:
#line 515 "MiniC.y" /* yacc.c:1646  */
    {(yyval.vchar)='-';}
#line 2267 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 34:
#line 516 "MiniC.y" /* yacc.c:1646  */
    {(yyval.vchar)='~';}
#line 2273 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 35:
#line 517 "MiniC.y" /* yacc.c:1646  */
    {(yyval.vchar)='!';}
#line 2279 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 36:
#line 521 "MiniC.y" /* yacc.c:1646  */
    {(yyval.expression_s) = (yyvsp[0].expression_s);}
#line 2285 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 37:
#line 522 "MiniC.y" /* yacc.c:1646  */
    {
		#warning "can not cast struct yet!";
		if(type_to_type[(yyvsp[-2].type_name_s)->type][(yyvsp[0].expression_s).type->type]==-1) //可以直接利用这个表来判断强制转换的合法性,暂时不允许同样结构体的强转
			yyerror("invalid cast!");
		get_cast_exp((yyval.expression_s), (yyvsp[-2].type_name_s), (yyvsp[0].expression_s));
	}
#line 2296 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 38:
#line 531 "MiniC.y" /* yacc.c:1646  */
    {(yyval.expression_s) = (yyvsp[0].expression_s);}
#line 2302 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 39:
#line 532 "MiniC.y" /* yacc.c:1646  */
    {get_ADD_SUB_MUL_DIV((yyval.expression_s),(yyvsp[-2].expression_s),(yyvsp[0].expression_s),"*");}
#line 2308 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 40:
#line 533 "MiniC.y" /* yacc.c:1646  */
    {get_ADD_SUB_MUL_DIV((yyval.expression_s),(yyvsp[-2].expression_s),(yyvsp[0].expression_s),"/");}
#line 2314 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 41:
#line 534 "MiniC.y" /* yacc.c:1646  */
    {get_MOD_AND_OR_XOR_LEFT_RIGHT((yyval.expression_s),(yyvsp[-2].expression_s),(yyvsp[0].expression_s),"%");}
#line 2320 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 42:
#line 538 "MiniC.y" /* yacc.c:1646  */
    {(yyval.expression_s) = (yyvsp[0].expression_s);}
#line 2326 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 43:
#line 539 "MiniC.y" /* yacc.c:1646  */
    {get_ADD_SUB_MUL_DIV((yyval.expression_s),(yyvsp[-2].expression_s),(yyvsp[0].expression_s),"+");}
#line 2332 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 44:
#line 540 "MiniC.y" /* yacc.c:1646  */
    {get_ADD_SUB_MUL_DIV((yyval.expression_s),(yyvsp[-2].expression_s),(yyvsp[0].expression_s),"-");}
#line 2338 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 45:
#line 544 "MiniC.y" /* yacc.c:1646  */
    {(yyval.expression_s) = (yyvsp[0].expression_s);}
#line 2344 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 46:
#line 545 "MiniC.y" /* yacc.c:1646  */
    {get_MOD_AND_OR_XOR_LEFT_RIGHT((yyval.expression_s),(yyvsp[-2].expression_s),(yyvsp[0].expression_s),"<<");}
#line 2350 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 47:
#line 546 "MiniC.y" /* yacc.c:1646  */
    {get_MOD_AND_OR_XOR_LEFT_RIGHT((yyval.expression_s),(yyvsp[-2].expression_s),(yyvsp[0].expression_s),">>");}
#line 2356 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 48:
#line 550 "MiniC.y" /* yacc.c:1646  */
    {(yyval.expression_s) = (yyvsp[0].expression_s);}
#line 2362 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 49:
#line 551 "MiniC.y" /* yacc.c:1646  */
    {get_relational_equality((yyval.expression_s), (yyvsp[-2].expression_s), (yyvsp[0].expression_s), "<");}
#line 2368 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 50:
#line 552 "MiniC.y" /* yacc.c:1646  */
    {get_relational_equality((yyval.expression_s), (yyvsp[-2].expression_s), (yyvsp[0].expression_s), ">");}
#line 2374 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 51:
#line 553 "MiniC.y" /* yacc.c:1646  */
    {get_relational_equality((yyval.expression_s), (yyvsp[-2].expression_s), (yyvsp[0].expression_s), "<=");}
#line 2380 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 52:
#line 554 "MiniC.y" /* yacc.c:1646  */
    {get_relational_equality((yyval.expression_s), (yyvsp[-2].expression_s), (yyvsp[0].expression_s), ">=");}
#line 2386 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 53:
#line 558 "MiniC.y" /* yacc.c:1646  */
    {(yyval.expression_s) = (yyvsp[0].expression_s);}
#line 2392 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 54:
#line 559 "MiniC.y" /* yacc.c:1646  */
    {get_relational_equality((yyval.expression_s), (yyvsp[-2].expression_s), (yyvsp[0].expression_s), "==");}
#line 2398 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 55:
#line 560 "MiniC.y" /* yacc.c:1646  */
    {get_relational_equality((yyval.expression_s), (yyvsp[-2].expression_s), (yyvsp[0].expression_s), "!=");}
#line 2404 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 56:
#line 564 "MiniC.y" /* yacc.c:1646  */
    {(yyval.expression_s) = (yyvsp[0].expression_s);}
#line 2410 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 57:
#line 565 "MiniC.y" /* yacc.c:1646  */
    {get_MOD_AND_OR_XOR_LEFT_RIGHT((yyval.expression_s),(yyvsp[-2].expression_s),(yyvsp[0].expression_s),"&");}
#line 2416 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 58:
#line 569 "MiniC.y" /* yacc.c:1646  */
    {(yyval.expression_s) = (yyvsp[0].expression_s);}
#line 2422 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 59:
#line 570 "MiniC.y" /* yacc.c:1646  */
    {get_MOD_AND_OR_XOR_LEFT_RIGHT((yyval.expression_s),(yyvsp[-2].expression_s),(yyvsp[0].expression_s),"^");}
#line 2428 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 60:
#line 574 "MiniC.y" /* yacc.c:1646  */
    {(yyval.expression_s) = (yyvsp[0].expression_s);}
#line 2434 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 61:
#line 575 "MiniC.y" /* yacc.c:1646  */
    {get_MOD_AND_OR_XOR_LEFT_RIGHT((yyval.expression_s),(yyvsp[-2].expression_s),(yyvsp[0].expression_s),"|");}
#line 2440 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 62:
#line 579 "MiniC.y" /* yacc.c:1646  */
    {(yyval.expression_s) = (yyvsp[0].expression_s);}
#line 2446 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 63:
#line 580 "MiniC.y" /* yacc.c:1646  */
    {
		gen_label((yyvsp[-1].vint));
		get_AND_OR((yyval.expression_s),(yyvsp[-3].expression_s),(yyvsp[0].expression_s),"&&");
	}
#line 2455 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 64:
#line 587 "MiniC.y" /* yacc.c:1646  */
    {(yyval.expression_s) = (yyvsp[0].expression_s);}
#line 2461 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 65:
#line 588 "MiniC.y" /* yacc.c:1646  */
    {
		gen_label((yyvsp[-1].vint));
		get_AND_OR((yyval.expression_s),(yyvsp[-3].expression_s),(yyvsp[0].expression_s),"||");		
	}
#line 2470 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 66:
#line 595 "MiniC.y" /* yacc.c:1646  */
    {(yyval.expression_s) = (yyvsp[0].expression_s);}
#line 2476 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 67:
#line 596 "MiniC.y" /* yacc.c:1646  */
    { (yyval.vint) = CreateLabel(); gen_goto((yyval.vint)); gen_label((yyvsp[-2].vint));}
#line 2482 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 68:
#line 596 "MiniC.y" /* yacc.c:1646  */
    {
		//????? 这玩意类型不确定啊。。。没法翻译啊 答：没问题，编译器会自动把他们转成 type_to_type 类型的！
		/*应该不用再次跳转了
		//
		*/
		gen_label((yyvsp[-2].vint));
		int lab1 = CreateLabel(), lab2 = CreateLabel();
		
		if(type_to_type[(yyvsp[-3].expression_s).type->type][(yyvsp[0].expression_s).type->type]==-1)
			if(check_str_un((yyvsp[-3].expression_s)) && check_str_un((yyvsp[0].expression_s)))
			{
				if(!sameType((yyvsp[-3].expression_s).type, (yyvsp[0].expression_s).type))
					yyerror("two expression in the conditional_expression must have semilar type");
			}
			else yyerror("two expression in the conditional_expression must have semilar type");
		
		(yyval.expression_s).addr = get_TAC_name('t',CreateTempVar());
		if(check_str_un((yyvsp[-3].expression_s)))
		{
			(yyval.expression_s).type = (yyvsp[-3].expression_s).type;
			gen_var("ptr",(yyval.expression_s).addr);
		}
		else
		{
			(yyval.expression_s).type = get_Typename_t(type_to_type[(yyvsp[-3].expression_s).type->type][(yyvsp[0].expression_s).type->type]);
			gen_var(map_name[type_to_type[(yyvsp[-3].expression_s).type->type][(yyvsp[0].expression_s).type->type]], (yyval.expression_s).addr);
		}
		(yyval.expression_s).lr_value = 1;//变成右值！
		(yyval.expression_s).isConst = 0;
		(yyval.expression_s).laddr = NULL;
		
		genIfGoto((yyvsp[-6].expression_s), "t0", "==", lab2); //等于0就要跳到后面去

		//下面这段是逻辑表达式值为1的时候执行的语句
		if(check_str_un((yyvsp[-3].expression_s)))
			gen_cpy((yyval.expression_s).addr, (yyvsp[-3].expression_s).addr);
		else 
			gen_cpy((yyval.expression_s).addr, get_cast_name(type_to_type[(yyvsp[-3].expression_s).type->type][(yyvsp[0].expression_s).type->type], (yyvsp[-3].expression_s).type->type, (yyvsp[-3].expression_s).get_addr()));
		gen_goto(lab1);

		gen_label(lab2);
		if(check_str_un((yyvsp[0].expression_s)))
			gen_cpy((yyval.expression_s).addr, (yyvsp[0].expression_s).addr);
		else 
			gen_cpy((yyval.expression_s).addr, get_cast_name(type_to_type[(yyvsp[-3].expression_s).type->type][(yyvsp[0].expression_s).type->type], (yyvsp[0].expression_s).type->type, (yyvsp[0].expression_s).get_addr()));
		gen_label(lab1);
	}
#line 2534 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 69:
#line 646 "MiniC.y" /* yacc.c:1646  */
    {
			//需要根据前一个逻辑运算符是什么，来决定怎么跳转
			(yyval.vint) = CreateLabel();
			if((yyvsp[0].vint) == 0) //0 表示 &&， 1表示 ||
				genIfGoto((yyvsp[(-1) - (0)].expression_s), "t0", "==", (yyval.vint));
			else genIfGoto((yyvsp[(-1) - (0)].expression_s), "t1", "==", (yyval.vint));
		}
#line 2546 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 70:
#line 656 "MiniC.y" /* yacc.c:1646  */
    {(yyval.expression_s) = (yyvsp[0].expression_s);}
#line 2552 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 71:
#line 657 "MiniC.y" /* yacc.c:1646  */
    {
		if((yyvsp[-1].vint) == 0)
		{
			(yyval.expression_s) = get_assign((yyvsp[-2].expression_s),(yyvsp[0].expression_s));	
		}
		else
		{
			expression_s_t tmp;
			if((yyvsp[-1].vint) == ADD_ASSIGN)
				get_ADD_SUB_MUL_DIV(tmp,(yyvsp[-2].expression_s),(yyvsp[0].expression_s),"+");
			else if((yyvsp[-1].vint) == SUB_ASSIGN)
				get_ADD_SUB_MUL_DIV(tmp,(yyvsp[-2].expression_s),(yyvsp[0].expression_s),"-");
			else if((yyvsp[-1].vint) == MUL_ASSIGN)
				get_ADD_SUB_MUL_DIV(tmp,(yyvsp[-2].expression_s),(yyvsp[0].expression_s),"*");
			else if((yyvsp[-1].vint) == DIV_ASSIGN)
				get_ADD_SUB_MUL_DIV(tmp,(yyvsp[-2].expression_s),(yyvsp[0].expression_s),"/");
			else if((yyvsp[-1].vint) == MOD_ASSIGN)
				get_MOD_AND_OR_XOR_LEFT_RIGHT(tmp,(yyvsp[-2].expression_s),(yyvsp[0].expression_s),"%");
			else if((yyvsp[-1].vint) == LEFT_ASSIGN)
				get_MOD_AND_OR_XOR_LEFT_RIGHT(tmp,(yyvsp[-2].expression_s),(yyvsp[0].expression_s),"<<");
			else if((yyvsp[-1].vint) == RIGHT_ASSIGN)
				get_MOD_AND_OR_XOR_LEFT_RIGHT(tmp,(yyvsp[-2].expression_s),(yyvsp[0].expression_s),">>");
			else if((yyvsp[-1].vint) == OR_ASSIGN)
				get_MOD_AND_OR_XOR_LEFT_RIGHT(tmp,(yyvsp[-2].expression_s),(yyvsp[0].expression_s),"|");
			else if((yyvsp[-1].vint) == XOR_ASSIGN)
				get_MOD_AND_OR_XOR_LEFT_RIGHT(tmp,(yyvsp[-2].expression_s),(yyvsp[0].expression_s),"^");
			else if((yyvsp[-1].vint) == AND_ASSIGN)
				get_MOD_AND_OR_XOR_LEFT_RIGHT(tmp,(yyvsp[-2].expression_s),(yyvsp[0].expression_s),"&");
			(yyval.expression_s) = get_assign((yyvsp[-2].expression_s),tmp);
		}
    }
#line 2588 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 72:
#line 691 "MiniC.y" /* yacc.c:1646  */
    {
		  (yyval.vint) = 0; //0 表示等号
	  }
#line 2596 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 73:
#line 694 "MiniC.y" /* yacc.c:1646  */
    {(yyval.vint) = MUL_ASSIGN;}
#line 2602 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 74:
#line 695 "MiniC.y" /* yacc.c:1646  */
    {(yyval.vint) = DIV_ASSIGN;}
#line 2608 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 75:
#line 696 "MiniC.y" /* yacc.c:1646  */
    {(yyval.vint) = MOD_ASSIGN;}
#line 2614 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 76:
#line 697 "MiniC.y" /* yacc.c:1646  */
    {(yyval.vint) = ADD_ASSIGN;}
#line 2620 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 77:
#line 698 "MiniC.y" /* yacc.c:1646  */
    {(yyval.vint) = SUB_ASSIGN;}
#line 2626 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 78:
#line 699 "MiniC.y" /* yacc.c:1646  */
    {(yyval.vint) = LEFT_ASSIGN;}
#line 2632 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 79:
#line 700 "MiniC.y" /* yacc.c:1646  */
    {(yyval.vint) = RIGHT_ASSIGN;}
#line 2638 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 80:
#line 701 "MiniC.y" /* yacc.c:1646  */
    {(yyval.vint) = AND_ASSIGN;}
#line 2644 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 81:
#line 702 "MiniC.y" /* yacc.c:1646  */
    {(yyval.vint) = XOR_ASSIGN;}
#line 2650 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 82:
#line 703 "MiniC.y" /* yacc.c:1646  */
    {(yyval.vint) = OR_ASSIGN;}
#line 2656 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 83:
#line 707 "MiniC.y" /* yacc.c:1646  */
    {(yyval.expression_s) = (yyvsp[0].expression_s);}
#line 2662 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 84:
#line 708 "MiniC.y" /* yacc.c:1646  */
    {(yyval.expression_s) = (yyvsp[0].expression_s);}
#line 2668 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 85:
#line 712 "MiniC.y" /* yacc.c:1646  */
    {(yyval.expression_s) = (yyvsp[0].expression_s);}
#line 2674 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 86:
#line 716 "MiniC.y" /* yacc.c:1646  */
    {(yyval.storage_class_specifier_s).hasTYPEDEF = 1; (yyval.storage_class_specifier_s).hasSTATIC = 0;}
#line 2680 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 87:
#line 717 "MiniC.y" /* yacc.c:1646  */
    {(yyval.storage_class_specifier_s).hasTYPEDEF = 0; (yyval.storage_class_specifier_s).hasSTATIC = 1;}
#line 2686 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 88:
#line 721 "MiniC.y" /* yacc.c:1646  */
    {(yyval.type_qualifier_s).hasCONST = 1;}
#line 2692 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 89:
#line 725 "MiniC.y" /* yacc.c:1646  */
    {(yyval.type_specifier_s).type = (const_Typename_ptr)LookupSymbol("void", NULL); (yyval.type_specifier_s).sign=-1;}
#line 2698 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 90:
#line 726 "MiniC.y" /* yacc.c:1646  */
    {(yyval.type_specifier_s).type = (const_Typename_ptr)LookupSymbol("char", NULL); (yyval.type_specifier_s).sign=-1;}
#line 2704 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 91:
#line 727 "MiniC.y" /* yacc.c:1646  */
    {(yyval.type_specifier_s).type = (const_Typename_ptr)LookupSymbol("short", NULL); (yyval.type_specifier_s).sign=-1;}
#line 2710 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 92:
#line 728 "MiniC.y" /* yacc.c:1646  */
    {(yyval.type_specifier_s).type = (const_Typename_ptr)LookupSymbol("int", NULL); (yyval.type_specifier_s).sign=-1;}
#line 2716 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 93:
#line 729 "MiniC.y" /* yacc.c:1646  */
    {(yyval.type_specifier_s).type = (const_Typename_ptr)LookupSymbol("long", NULL); (yyval.type_specifier_s).sign=-1;}
#line 2722 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 94:
#line 730 "MiniC.y" /* yacc.c:1646  */
    {(yyval.type_specifier_s).type = (const_Typename_ptr)LookupSymbol("float", NULL); (yyval.type_specifier_s).sign=-1;}
#line 2728 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 95:
#line 731 "MiniC.y" /* yacc.c:1646  */
    {(yyval.type_specifier_s).type = (const_Typename_ptr)LookupSymbol("double", NULL); (yyval.type_specifier_s).sign=-1;}
#line 2734 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 96:
#line 732 "MiniC.y" /* yacc.c:1646  */
    {(yyval.type_specifier_s).type = (const_Typename_ptr)LookupSymbol("int", NULL); (yyval.type_specifier_s).sign=1;}
#line 2740 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 97:
#line 733 "MiniC.y" /* yacc.c:1646  */
    {(yyval.type_specifier_s).type = (const_Typename_ptr)LookupSymbol("unsigned int", NULL); (yyval.type_specifier_s).sign=0;}
#line 2746 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 98:
#line 734 "MiniC.y" /* yacc.c:1646  */
    {(yyval.type_specifier_s).type = (yyvsp[0].struct_or_union_specifier_s); (yyval.type_specifier_s).sign=-1;}
#line 2752 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 99:
#line 735 "MiniC.y" /* yacc.c:1646  */
    {(yyval.type_specifier_s).type = (yyvsp[0].enum_specifier_s); (yyval.type_specifier_s).sign=-1;}
#line 2758 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 100:
#line 736 "MiniC.y" /* yacc.c:1646  */
    {(yyval.type_specifier_s).type = (const_Typename_ptr)(yyvsp[0].vptr); (yyval.type_specifier_s).sign=-1;}
#line 2764 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 101:
#line 740 "MiniC.y" /* yacc.c:1646  */
    {(yyval.declaration_specifiers_s) = (yyvsp[0].declaration_specifiers_s); (yyval.declaration_specifiers_s).hasTYPEDEF |= (yyvsp[-1].storage_class_specifier_s).hasTYPEDEF; (yyval.declaration_specifiers_s).hasSTATIC |= (yyvsp[-1].storage_class_specifier_s).hasSTATIC;}
#line 2770 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 102:
#line 741 "MiniC.y" /* yacc.c:1646  */
    {(yyval.declaration_specifiers_s).hasTYPEDEF = (yyvsp[0].storage_class_specifier_s).hasTYPEDEF; (yyval.declaration_specifiers_s).hasSTATIC = (yyvsp[0].storage_class_specifier_s).hasSTATIC; (yyval.declaration_specifiers_s).hasCONST = 0; (yyval.declaration_specifiers_s).sign = -1; (yyval.declaration_specifiers_s).type = NULL;}
#line 2776 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 103:
#line 742 "MiniC.y" /* yacc.c:1646  */
    {(yyval.declaration_specifiers_s) = (yyvsp[0].declaration_specifiers_s); TypeCombine((yyvsp[-1].type_specifier_s).sign, (yyvsp[-1].type_specifier_s).type, &((yyval.declaration_specifiers_s).sign), &((yyval.declaration_specifiers_s).type));}
#line 2782 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 104:
#line 743 "MiniC.y" /* yacc.c:1646  */
    {(yyval.declaration_specifiers_s).hasTYPEDEF=(yyval.declaration_specifiers_s).hasSTATIC=(yyval.declaration_specifiers_s).hasCONST=0; (yyval.declaration_specifiers_s).sign = (yyvsp[0].type_specifier_s).sign; (yyval.declaration_specifiers_s).type = (yyvsp[0].type_specifier_s).type;}
#line 2788 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 105:
#line 744 "MiniC.y" /* yacc.c:1646  */
    {(yyval.declaration_specifiers_s) = (yyvsp[0].declaration_specifiers_s); (yyval.declaration_specifiers_s).hasCONST |= (yyvsp[-1].type_qualifier_s).hasCONST;}
#line 2794 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 106:
#line 745 "MiniC.y" /* yacc.c:1646  */
    {(yyval.declaration_specifiers_s).hasTYPEDEF=(yyval.declaration_specifiers_s).hasSTATIC=0; (yyval.declaration_specifiers_s).hasCONST = (yyvsp[0].type_qualifier_s).hasCONST; (yyval.declaration_specifiers_s).sign = -1; (yyval.declaration_specifiers_s).type = NULL;}
#line 2800 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 107:
#line 749 "MiniC.y" /* yacc.c:1646  */
    {(yyval.init_declarator_s).decl = (yyvsp[-2].declarator_s); (yyval.init_declarator_s).init = memDup(&(yyvsp[0].initializer_s));}
#line 2806 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 108:
#line 750 "MiniC.y" /* yacc.c:1646  */
    {(yyval.init_declarator_s).decl = (yyvsp[0].declarator_s); (yyval.init_declarator_s).init = NULL;}
#line 2812 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 109:
#line 754 "MiniC.y" /* yacc.c:1646  */
    {(yyval.init_declarator_list_s)=new init_declarator_list_s_t; (yyval.init_declarator_list_s)->idecl=(yyvsp[0].init_declarator_s); (yyval.init_declarator_list_s)->next=NULL;}
#line 2818 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 110:
#line 755 "MiniC.y" /* yacc.c:1646  */
    {(yyval.init_declarator_list_s)=new init_declarator_list_s_t; (yyval.init_declarator_list_s)->idecl=(yyvsp[0].init_declarator_s); (yyval.init_declarator_list_s)->next=(yyvsp[-2].init_declarator_list_s);}
#line 2824 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 112:
#line 760 "MiniC.y" /* yacc.c:1646  */
    {
            if ((yyvsp[-2].declaration_specifiers_s).type==NULL)yyerror("declaration error");
            if ((yyvsp[-2].declaration_specifiers_s).hasTYPEDEF && (yyvsp[-2].declaration_specifiers_s).hasSTATIC) yyerror("typedef with static");
            const_Typename_ptr tmptype = (yyvsp[-2].declaration_specifiers_s).type;
            if ((yyvsp[-2].declaration_specifiers_s).hasCONST)
                tmptype = addConst((yyvsp[-2].declaration_specifiers_s).type);
            for (init_declarator_list_s_t *i = (yyvsp[-1].init_declarator_list_s); i; i = i->next) {
                Identifier_t *id = StackDeclare(makeType(tmptype, i->idecl.decl), (yyvsp[-2].declaration_specifiers_s).hasSTATIC, (yyvsp[-2].declaration_specifiers_s).hasTYPEDEF, getDeclaratorName(&(i->idecl.decl)));
                if (!(yyvsp[-2].declaration_specifiers_s).hasTYPEDEF) {
                    genDeclare(id->type, id->TACname, symbolStack->next == NULL || (yyvsp[-2].declaration_specifiers_s).hasSTATIC);
                    genInitilize(id->type, id->TACname, i->idecl.init);
                    if (i->idecl.init && (i->idecl.init->data.addr || i->idecl.init->data.laddr) && id->type->isConst) {
                        id->isConst = 1;
                        id->value = i->idecl.init->data.value;
                    }
                    else
                        id->isConst = 0;
                } else
                    if (i->idecl.init)
                        yyerror("typedef with initial value");
            }
            freeIDL((yyvsp[-1].init_declarator_list_s));
        }
#line 2852 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 113:
#line 786 "MiniC.y" /* yacc.c:1646  */
    {(yyval.struct_or_union_s).hasSTRUCT=1;(yyval.struct_or_union_s).hasUNION=0;}
#line 2858 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 114:
#line 787 "MiniC.y" /* yacc.c:1646  */
    {(yyval.struct_or_union_s).hasSTRUCT=0;(yyval.struct_or_union_s).hasUNION=1;}
#line 2864 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 115:
#line 791 "MiniC.y" /* yacc.c:1646  */
    {
            Typename_t *t = newStructUnion((yyvsp[-4].struct_or_union_s).hasSTRUCT, NULL, true);
            symbolStack = symbolStack->next;
            (yyval.struct_or_union_specifier_s) = StackAddTypename(t);
        }
#line 2874 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 116:
#line 796 "MiniC.y" /* yacc.c:1646  */
    {
            Typename_t *t = newStructUnion((yyvsp[-2].struct_or_union_s).hasSTRUCT, (yyvsp[-1].vstr), false);
            int symbol_type;
            void *ptr = LookupSymbol(t->name, &symbol_type);
            if (symbol_type != TYPE_NAME && ptr)
                yyerror("identifier already exists");
            if (ptr)
                delete t;
            else
                StackAddTypename(t);
            PushSymbolStack(0);
        }
#line 2891 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 117:
#line 807 "MiniC.y" /* yacc.c:1646  */
    {
            Typename_t *t = newStructUnion((yyvsp[-5].struct_or_union_s).hasSTRUCT, (yyvsp[-4].vstr), true);
            symbolStack = symbolStack->next;
            (yyval.struct_or_union_specifier_s) = StackAddTypename(t);
        }
#line 2901 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 118:
#line 812 "MiniC.y" /* yacc.c:1646  */
    {
            Typename_t *t = newStructUnion((yyvsp[-3].struct_or_union_s).hasSTRUCT, NULL, true);
            symbolStack = symbolStack->next;
            (yyval.struct_or_union_specifier_s) = StackAddTypename(t);
        }
#line 2911 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 119:
#line 817 "MiniC.y" /* yacc.c:1646  */
    {
            Typename_t *t = newStructUnion((yyvsp[-4].struct_or_union_s).hasSTRUCT, (yyvsp[-3].vstr), true);
            symbolStack = symbolStack->next;
            (yyval.struct_or_union_specifier_s) = StackAddTypename(t);
        }
#line 2921 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 120:
#line 822 "MiniC.y" /* yacc.c:1646  */
    {
            Typename_t *t = newStructUnion((yyvsp[-1].struct_or_union_s).hasSTRUCT, (yyvsp[0].vstr), false);
            int symbol_type;
            void *ptr = LookupSymbol(t->name, &symbol_type);
            if (symbol_type != TYPE_NAME && ptr)
                yyerror("identifier already exists");
            if (ptr) {
                (yyval.struct_or_union_specifier_s) = (const_Typename_ptr)ptr;
                delete t;
            }
            else
                (yyval.struct_or_union_specifier_s) = StackAddTypename(t);
        }
#line 2939 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 121:
#line 837 "MiniC.y" /* yacc.c:1646  */
    {PushSymbolStack(0);}
#line 2945 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 122:
#line 840 "MiniC.y" /* yacc.c:1646  */
    {(yyval.specifier_qualifier_list_s) = (yyvsp[0].specifier_qualifier_list_s); TypeCombine((yyvsp[-1].type_specifier_s).sign, (yyvsp[-1].type_specifier_s).type, &((yyval.specifier_qualifier_list_s).sign), &((yyval.specifier_qualifier_list_s).type));}
#line 2951 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 123:
#line 841 "MiniC.y" /* yacc.c:1646  */
    {(yyval.specifier_qualifier_list_s).hasCONST=0; (yyval.specifier_qualifier_list_s).sign=(yyvsp[0].type_specifier_s).sign; (yyval.specifier_qualifier_list_s).type=(yyvsp[0].type_specifier_s).type;}
#line 2957 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 124:
#line 842 "MiniC.y" /* yacc.c:1646  */
    {(yyval.specifier_qualifier_list_s) = (yyvsp[0].specifier_qualifier_list_s); (yyval.specifier_qualifier_list_s).hasCONST = (yyvsp[-1].type_qualifier_s).hasCONST;}
#line 2963 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 125:
#line 843 "MiniC.y" /* yacc.c:1646  */
    {(yyval.specifier_qualifier_list_s).hasCONST = (yyvsp[0].type_qualifier_s).hasCONST; (yyval.specifier_qualifier_list_s).sign = -1; (yyval.specifier_qualifier_list_s).type = NULL;}
#line 2969 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 126:
#line 847 "MiniC.y" /* yacc.c:1646  */
    {(yyval.struct_declarator_list_s)=new struct_declarator_list_s_t;(yyval.struct_declarator_list_s)->next=NULL;(yyval.struct_declarator_list_s)->decl=(yyvsp[0].declarator_s);}
#line 2975 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 127:
#line 848 "MiniC.y" /* yacc.c:1646  */
    {(yyval.struct_declarator_list_s)=new struct_declarator_list_s_t;(yyval.struct_declarator_list_s)->next=(yyvsp[-2].struct_declarator_list_s);(yyval.struct_declarator_list_s)->decl=(yyvsp[0].declarator_s);}
#line 2981 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 128:
#line 852 "MiniC.y" /* yacc.c:1646  */
    {if ((yyvsp[-1].specifier_qualifier_list_s).type==NULL)yyerror("struct declaration error");}
#line 2987 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 129:
#line 853 "MiniC.y" /* yacc.c:1646  */
    {
            if ((yyvsp[-2].specifier_qualifier_list_s).type==NULL)yyerror("struct declaration error");
            const_Typename_ptr tmptype = (yyvsp[-2].specifier_qualifier_list_s).type;
            if ((yyvsp[-2].specifier_qualifier_list_s).hasCONST)
                tmptype = addConst((yyvsp[-2].specifier_qualifier_list_s).type);
            for (struct_declarator_list_s_t *i = (yyvsp[-1].struct_declarator_list_s); i; i = i->next)
                StackDeclare(makeType(tmptype, i->decl), 0, 0, getDeclaratorName(&(i->decl)));
            freeSDL((yyvsp[-1].struct_declarator_list_s));
        }
#line 3001 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 132:
#line 870 "MiniC.y" /* yacc.c:1646  */
    { (yyval.enum_specifier_s) = newEnum(NULL, (yyvsp[-1].enumerator_list_s)); StackAddEnumTable((yyvsp[-1].enumerator_list_s)); }
#line 3007 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 133:
#line 871 "MiniC.y" /* yacc.c:1646  */
    { (yyval.enum_specifier_s) = newEnum(NULL, (yyvsp[-2].enumerator_list_s)); StackAddEnumTable((yyvsp[-2].enumerator_list_s)); }
#line 3013 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 134:
#line 872 "MiniC.y" /* yacc.c:1646  */
    { (yyval.enum_specifier_s) = newEnum((yyvsp[-3].vstr), (yyvsp[-1].enumerator_list_s)); StackAddEnumTable((yyvsp[-1].enumerator_list_s)); }
#line 3019 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 135:
#line 873 "MiniC.y" /* yacc.c:1646  */
    { (yyval.enum_specifier_s) = newEnum((yyvsp[-4].vstr), (yyvsp[-2].enumerator_list_s)); StackAddEnumTable((yyvsp[-2].enumerator_list_s)); }
#line 3025 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 136:
#line 874 "MiniC.y" /* yacc.c:1646  */
    {
            Typename_t *t = new Typename_t;
            t->type = idt_int; // idt_enum is replaced by idt_int
            t->name = strdup((std::string("enum ") + (yyvsp[0].vstr)).c_str());
            t->structure = NULL;
            StackAddTypename(t);
            t->size = -1;
            (yyval.enum_specifier_s) = t;
        }
#line 3039 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 137:
#line 886 "MiniC.y" /* yacc.c:1646  */
    {(yyval.vint)=0;}
#line 3045 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 138:
#line 886 "MiniC.y" /* yacc.c:1646  */
    {(yyval.enumerator_list_s)=new EnumTable_t; (yyval.enumerator_list_s)->name=(yyvsp[0].enumerator_s).name; (yyval.enumerator_list_s)->value=(yyvsp[0].enumerator_s).value; (yyval.enumerator_list_s)->next=NULL;}
#line 3051 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 139:
#line 887 "MiniC.y" /* yacc.c:1646  */
    {(yyval.vint)=(yyvsp[-1].enumerator_list_s)->value + 1;}
#line 3057 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 140:
#line 887 "MiniC.y" /* yacc.c:1646  */
    {
            (yyval.enumerator_list_s)=new EnumTable_t;
            (yyval.enumerator_list_s)->name = (yyvsp[0].enumerator_s).name;
            (yyval.enumerator_list_s)->value = (yyvsp[0].enumerator_s).value;
            (yyval.enumerator_list_s)->next = (yyvsp[-3].enumerator_list_s);
        }
#line 3068 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 141:
#line 896 "MiniC.y" /* yacc.c:1646  */
    {(yyval.enumerator_s).name=(yyvsp[-2].vstr); (yyval.enumerator_s).value=(yyvsp[0].expression_s).value.vint;
                                                if (!(yyvsp[0].expression_s).isConst||!type_of_const_exp[(yyvsp[0].expression_s).type->type]) yyerror("enumerator not integer constant");}
#line 3075 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 142:
#line 898 "MiniC.y" /* yacc.c:1646  */
    {(yyval.enumerator_s).name=(yyvsp[0].vstr); (yyval.enumerator_s).value=(yyvsp[-1].vint);}
#line 3081 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 143:
#line 902 "MiniC.y" /* yacc.c:1646  */
    {(yyval.direct_declarator_s).type=1; (yyval.direct_declarator_s).data.d1=(yyvsp[0].vstr);}
#line 3087 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 144:
#line 903 "MiniC.y" /* yacc.c:1646  */
    {(yyval.direct_declarator_s).type=2; (yyval.direct_declarator_s).data.d2=(yyvsp[-1].declarator_s);}
#line 3093 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 145:
#line 904 "MiniC.y" /* yacc.c:1646  */
    {(yyval.direct_declarator_s).type=3; (yyval.direct_declarator_s).data.d3=memDup(&(yyvsp[-2].direct_declarator_s));}
#line 3099 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 146:
#line 905 "MiniC.y" /* yacc.c:1646  */
    {(yyval.direct_declarator_s).type=4; if (!(yyvsp[-1].expression_s).isConst||!type_of_const_exp[(yyvsp[-1].expression_s).type->type]) yyerror("array declaration not integer constant"); (yyval.direct_declarator_s).data.d4.dd=memDup(&(yyvsp[-3].direct_declarator_s)); (yyval.direct_declarator_s).data.d4.ce=(yyvsp[-1].expression_s).value.vint;}
#line 3105 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 147:
#line 906 "MiniC.y" /* yacc.c:1646  */
    {(yyval.direct_declarator_s).type=5; (yyval.direct_declarator_s).data.d5.dd=memDup(&(yyvsp[-3].direct_declarator_s)); (yyval.direct_declarator_s).data.d5.pl=(yyvsp[-1].parameter_list_s); symbolStack = symbolStack->next;}
#line 3111 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 148:
#line 907 "MiniC.y" /* yacc.c:1646  */
    {(yyval.direct_declarator_s).type=6; (yyval.direct_declarator_s).data.d6=memDup(&(yyvsp[-2].direct_declarator_s));}
#line 3117 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 149:
#line 908 "MiniC.y" /* yacc.c:1646  */
    {yyerror("not support for this type of function declaration");}
#line 3123 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 150:
#line 912 "MiniC.y" /* yacc.c:1646  */
    {(yyval.pointer_s)=new pointer_list_t; (yyval.pointer_s)->hasConst=(yyvsp[-1].type_qualifier_s).hasCONST; (yyval.pointer_s)->next=(yyvsp[0].pointer_s);}
#line 3129 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 151:
#line 913 "MiniC.y" /* yacc.c:1646  */
    {(yyval.pointer_s)=new pointer_list_t; (yyval.pointer_s)->hasConst=(yyvsp[0].type_qualifier_s).hasCONST; (yyval.pointer_s)->next=NULL;}
#line 3135 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 152:
#line 914 "MiniC.y" /* yacc.c:1646  */
    {(yyval.pointer_s)=new pointer_list_t; (yyval.pointer_s)->hasConst=0; (yyval.pointer_s)->next=(yyvsp[0].pointer_s);}
#line 3141 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 153:
#line 915 "MiniC.y" /* yacc.c:1646  */
    {(yyval.pointer_s)=new pointer_list_t; (yyval.pointer_s)->hasConst=0; (yyval.pointer_s)->next=NULL;}
#line 3147 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 154:
#line 919 "MiniC.y" /* yacc.c:1646  */
    {(yyval.declarator_s).ptr=(yyvsp[-1].pointer_s); (yyval.declarator_s).dd=memDup(&(yyvsp[0].direct_declarator_s));}
#line 3153 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 155:
#line 920 "MiniC.y" /* yacc.c:1646  */
    {(yyval.declarator_s).ptr=NULL; (yyval.declarator_s).dd=memDup(&(yyvsp[0].direct_declarator_s));}
#line 3159 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 156:
#line 924 "MiniC.y" /* yacc.c:1646  */
    {
            if ((yyvsp[-1].declaration_specifiers_s).hasTYPEDEF || (yyvsp[-1].declaration_specifiers_s).hasSTATIC)
                yyerror("typedef/static in parameter");
            if ((yyvsp[-1].declaration_specifiers_s).hasCONST) {
                const_Typename_ptr p = addConst((yyvsp[-1].declaration_specifiers_s).type);
                StackDeclare(makeType(p, (yyvsp[0].declarator_s)), (yyvsp[-1].declaration_specifiers_s).hasSTATIC, (yyvsp[-1].declaration_specifiers_s).hasTYPEDEF, getDeclaratorName(&(yyvsp[0].declarator_s)));
            }
            else
                StackDeclare(makeType((yyvsp[-1].declaration_specifiers_s).type, (yyvsp[0].declarator_s)), (yyvsp[-1].declaration_specifiers_s).hasSTATIC, (yyvsp[-1].declaration_specifiers_s).hasTYPEDEF, getDeclaratorName(&(yyvsp[0].declarator_s)));
        }
#line 3174 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 157:
#line 934 "MiniC.y" /* yacc.c:1646  */
    {
            if ((yyvsp[-1].declaration_specifiers_s).hasTYPEDEF || (yyvsp[-1].declaration_specifiers_s).hasSTATIC)
                yyerror("typedef/static in parameter");
            if ((yyvsp[-1].declaration_specifiers_s).hasCONST) {
                const_Typename_ptr p = addConst((yyvsp[-1].declaration_specifiers_s).type);
                StackDeclare(makeType(p, (yyvsp[0].abstract_declarator_s)), (yyvsp[-1].declaration_specifiers_s).hasSTATIC, (yyvsp[-1].declaration_specifiers_s).hasTYPEDEF, NULL);
            }
            else
                StackDeclare(makeType((yyvsp[-1].declaration_specifiers_s).type, (yyvsp[0].abstract_declarator_s)), (yyvsp[-1].declaration_specifiers_s).hasSTATIC, (yyvsp[-1].declaration_specifiers_s).hasTYPEDEF, NULL);
        }
#line 3189 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 158:
#line 944 "MiniC.y" /* yacc.c:1646  */
    {
            if ((yyvsp[0].declaration_specifiers_s).hasTYPEDEF || (yyvsp[0].declaration_specifiers_s).hasSTATIC)
                yyerror("typedef/static in parameter");
            if ((yyvsp[0].declaration_specifiers_s).hasCONST) {
                const_Typename_ptr p = addConst((yyvsp[0].declaration_specifiers_s).type);
                StackDeclare(p, (yyvsp[0].declaration_specifiers_s).hasSTATIC, (yyvsp[0].declaration_specifiers_s).hasTYPEDEF, NULL);
            }
            else
                StackDeclare((yyvsp[0].declaration_specifiers_s).type, (yyvsp[0].declaration_specifiers_s).hasSTATIC, (yyvsp[0].declaration_specifiers_s).hasTYPEDEF, NULL);
        }
#line 3204 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 159:
#line 957 "MiniC.y" /* yacc.c:1646  */
    {PushSymbolStack(0);}
#line 3210 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 160:
#line 957 "MiniC.y" /* yacc.c:1646  */
    {(yyval.parameter_list_s)=symbolStack;}
#line 3216 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 161:
#line 958 "MiniC.y" /* yacc.c:1646  */
    {(yyval.parameter_list_s)=(yyvsp[-2].parameter_list_s);}
#line 3222 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 164:
#line 967 "MiniC.y" /* yacc.c:1646  */
    {
            if ((yyvsp[-1].specifier_qualifier_list_s).hasCONST)
                (yyval.type_name_s) = makeType(addConst((yyvsp[-1].specifier_qualifier_list_s).type), (yyvsp[0].abstract_declarator_s));
            else
                (yyval.type_name_s) = makeType((yyvsp[-1].specifier_qualifier_list_s).type, (yyvsp[0].abstract_declarator_s));
        }
#line 3233 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 165:
#line 973 "MiniC.y" /* yacc.c:1646  */
    {
            if ((yyvsp[0].specifier_qualifier_list_s).hasCONST)
                (yyval.type_name_s) = addConst((yyvsp[0].specifier_qualifier_list_s).type);
            else
                (yyval.type_name_s) = (yyvsp[0].specifier_qualifier_list_s).type;
        }
#line 3244 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 166:
#line 982 "MiniC.y" /* yacc.c:1646  */
    {(yyval.abstract_declarator_s).ptr = (yyvsp[-1].pointer_s); (yyval.abstract_declarator_s).dad = memDup(&(yyvsp[0].direct_abstract_declarator_s));}
#line 3250 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 167:
#line 983 "MiniC.y" /* yacc.c:1646  */
    {(yyval.abstract_declarator_s).ptr = (yyvsp[0].pointer_s); (yyval.abstract_declarator_s).dad = NULL;}
#line 3256 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 168:
#line 984 "MiniC.y" /* yacc.c:1646  */
    {(yyval.abstract_declarator_s).ptr = NULL; (yyval.abstract_declarator_s).dad = memDup(&(yyvsp[0].direct_abstract_declarator_s));}
#line 3262 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 169:
#line 988 "MiniC.y" /* yacc.c:1646  */
    {(yyval.direct_abstract_declarator_s).type=1; (yyval.direct_abstract_declarator_s).data.d1=(yyvsp[-1].abstract_declarator_s);}
#line 3268 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 170:
#line 989 "MiniC.y" /* yacc.c:1646  */
    {(yyval.direct_abstract_declarator_s).type=2;}
#line 3274 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 171:
#line 990 "MiniC.y" /* yacc.c:1646  */
    {(yyval.direct_abstract_declarator_s).type=3; if (!(yyvsp[-1].expression_s).isConst || !type_of_const_exp[(yyvsp[-1].expression_s).type->type]) yyerror("array declaration not integer constant"); (yyval.direct_abstract_declarator_s).data.d3=(yyvsp[-1].expression_s).value.vint;}
#line 3280 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 172:
#line 991 "MiniC.y" /* yacc.c:1646  */
    {(yyval.direct_abstract_declarator_s).type=4; (yyval.direct_abstract_declarator_s).data.d4=memDup(&(yyvsp[-2].direct_abstract_declarator_s));}
#line 3286 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 173:
#line 992 "MiniC.y" /* yacc.c:1646  */
    {(yyval.direct_abstract_declarator_s).type=5; (yyval.direct_abstract_declarator_s).data.d5.dad=memDup(&(yyvsp[-3].direct_abstract_declarator_s)); if (!(yyvsp[-1].expression_s).isConst || !type_of_const_exp[(yyvsp[-1].expression_s).type->type]) yyerror("array declaration not integer constant"); (yyval.direct_abstract_declarator_s).data.d5.ce=(yyvsp[-1].expression_s).value.vint;}
#line 3292 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 174:
#line 993 "MiniC.y" /* yacc.c:1646  */
    {(yyval.direct_abstract_declarator_s).type=6;}
#line 3298 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 175:
#line 994 "MiniC.y" /* yacc.c:1646  */
    {(yyval.direct_abstract_declarator_s).type=7; (yyval.direct_abstract_declarator_s).data.d7=(yyvsp[-1].parameter_list_s); symbolStack = symbolStack->next;}
#line 3304 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 176:
#line 995 "MiniC.y" /* yacc.c:1646  */
    {(yyval.direct_abstract_declarator_s).type=8; (yyval.direct_abstract_declarator_s).data.d8=memDup(&(yyvsp[-2].direct_abstract_declarator_s));}
#line 3310 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 177:
#line 996 "MiniC.y" /* yacc.c:1646  */
    {(yyval.direct_abstract_declarator_s).type=9; (yyval.direct_abstract_declarator_s).data.d9.dad=memDup(&(yyvsp[-3].direct_abstract_declarator_s)); (yyval.direct_abstract_declarator_s).data.d9.pl=(yyvsp[-1].parameter_list_s); symbolStack = symbolStack->next;}
#line 3316 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 180:
#line 1005 "MiniC.y" /* yacc.c:1646  */
    {(yyval.initializer_s).lst=(yyvsp[-1].initializer_list_s);(yyval.initializer_s).data.addr=NULL;(yyval.initializer_s).data.laddr=NULL;}
#line 3322 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 181:
#line 1006 "MiniC.y" /* yacc.c:1646  */
    {(yyval.initializer_s).lst=(yyvsp[-2].initializer_list_s);(yyval.initializer_s).data.addr=NULL;(yyval.initializer_s).data.laddr=NULL;}
#line 3328 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 182:
#line 1007 "MiniC.y" /* yacc.c:1646  */
    {(yyval.initializer_s).lst=NULL;(yyval.initializer_s).data.addr=NULL;(yyval.initializer_s).data.laddr=NULL;}
#line 3334 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 183:
#line 1008 "MiniC.y" /* yacc.c:1646  */
    {(yyval.initializer_s).lst=NULL;(yyval.initializer_s).data=(yyvsp[0].expression_s);}
#line 3340 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 184:
#line 1012 "MiniC.y" /* yacc.c:1646  */
    {yyerror("designator is not supported");}
#line 3346 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 185:
#line 1013 "MiniC.y" /* yacc.c:1646  */
    {(yyval.initializer_list_s)=new initializer_list_s_t; (yyval.initializer_list_s)->data=(yyvsp[0].initializer_s); (yyval.initializer_list_s)->next=NULL;}
#line 3352 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 186:
#line 1014 "MiniC.y" /* yacc.c:1646  */
    {yyerror("designator is not supported");}
#line 3358 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 187:
#line 1015 "MiniC.y" /* yacc.c:1646  */
    {(yyval.initializer_list_s)=new initializer_list_s_t; (yyval.initializer_list_s)->data=(yyvsp[0].initializer_s); (yyval.initializer_list_s)->next=(yyvsp[-2].initializer_list_s);}
#line 3364 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 190:
#line 1021 "MiniC.y" /* yacc.c:1646  */
    {(yyval.statement_s).caseList = NULL;}
#line 3370 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 194:
#line 1028 "MiniC.y" /* yacc.c:1646  */
    {yyerror("label not support");}
#line 3376 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 195:
#line 1029 "MiniC.y" /* yacc.c:1646  */
    {gen_label((yyval.vint) = CreateLabel());}
#line 3382 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 196:
#line 1029 "MiniC.y" /* yacc.c:1646  */
    {(yyval.statement_i)=(yyvsp[-4].statement_i);}
#line 3388 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 197:
#line 1029 "MiniC.y" /* yacc.c:1646  */
    {
            if (!(yyvsp[-4].expression_s).isConst)
                yyerror("case not constant");
            (yyval.statement_s).caseList = new CaseList_t;
            (yyval.statement_s).caseList->isDefault = 0;
            switch ((yyvsp[-4].expression_s).type->type) {
            case idt_char:
            case idt_uchar:
            case idt_short:
            case idt_ushort:
            case idt_int:
            case idt_uint:
            case idt_long:
            case idt_ulong:
                break;
            default:
                yyerror("case not integer");
            }
            (yyval.statement_s).caseList->type = (yyvsp[-4].expression_s).type->type;
            (yyval.statement_s).caseList->value = (yyvsp[-4].expression_s).get_addr();
            (yyval.statement_s).caseList->label = (yyvsp[-3].vint);
            (yyval.statement_s).caseList->next = NULL;
        }
#line 3416 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 198:
#line 1052 "MiniC.y" /* yacc.c:1646  */
    {gen_label((yyval.vint) = CreateLabel());}
#line 3422 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 199:
#line 1052 "MiniC.y" /* yacc.c:1646  */
    {(yyval.statement_i)=(yyvsp[-3].statement_i);}
#line 3428 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 200:
#line 1052 "MiniC.y" /* yacc.c:1646  */
    {
            (yyval.statement_s).caseList = new CaseList_t;
            (yyval.statement_s).caseList->isDefault = 1;
            (yyval.statement_s).caseList->label = (yyvsp[-3].vint);
            (yyval.statement_s).caseList->next = NULL;
        }
#line 3439 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 201:
#line 1061 "MiniC.y" /* yacc.c:1646  */
    {(yyval.statement_s).caseList=NULL;}
#line 3445 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 204:
#line 1067 "MiniC.y" /* yacc.c:1646  */
    {(yyval.statement_i) = (yyvsp[-1].statement_i);}
#line 3451 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 205:
#line 1067 "MiniC.y" /* yacc.c:1646  */
    {
            (yyval.statement_s).caseList = (yyvsp[0].statement_s).caseList;
            if ((yyval.statement_s).caseList == NULL)
                (yyval.statement_s).caseList = (yyvsp[-2].statement_s).caseList;
            else
                (yyval.statement_s).caseList->next = (yyvsp[-2].statement_s).caseList;
        }
#line 3463 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 206:
#line 1077 "MiniC.y" /* yacc.c:1646  */
    {
            PopSymbolStack();
            (yyval.statement_s).caseList = NULL;
        }
#line 3472 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 207:
#line 1081 "MiniC.y" /* yacc.c:1646  */
    {(yyval.statement_i) = (yyvsp[-2].statement_i); (yyval.statement_i).sblst = NULL;}
#line 3478 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 208:
#line 1081 "MiniC.y" /* yacc.c:1646  */
    {
            PopSymbolStack();
            (yyval.statement_s).caseList = (yyvsp[-1].statement_s).caseList;
        }
#line 3487 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 209:
#line 1087 "MiniC.y" /* yacc.c:1646  */
    {PushSymbolStack(1); declareParameter((yyvsp[(-1) - (0)].statement_i).sblst);}
#line 3493 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 210:
#line 1091 "MiniC.y" /* yacc.c:1646  */
    {(yyval.expression_statement_s).have = false;}
#line 3499 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 211:
#line 1092 "MiniC.y" /* yacc.c:1646  */
    {(yyval.expression_statement_s).have = true; (yyval.expression_statement_s).expr = (yyvsp[-1].expression_s);}
#line 3505 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 212:
#line 1096 "MiniC.y" /* yacc.c:1646  */
    {gen_goto((yyval.vint)=CreateLabel());}
#line 3511 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 213:
#line 1096 "MiniC.y" /* yacc.c:1646  */
    {
            gen_label((yyvsp[-5].vint));
            (yyval.statement_i)=(yyvsp[-9].statement_i);
        }
#line 3520 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 214:
#line 1099 "MiniC.y" /* yacc.c:1646  */
    {
            gen_label((yyvsp[-2].vint));
            (yyval.statement_s).caseList=NULL;
        }
#line 3529 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 215:
#line 1103 "MiniC.y" /* yacc.c:1646  */
    {gen_label((yyvsp[-3].vint)); (yyval.statement_s).caseList=NULL;}
#line 3535 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 216:
#line 1104 "MiniC.y" /* yacc.c:1646  */
    {gen_goto((yyval.vint)=CreateLabel());}
#line 3541 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 217:
#line 1104 "MiniC.y" /* yacc.c:1646  */
    {
            (yyval.statement_i)=(yyvsp[-5].statement_i);
            (yyval.statement_i).has_end=1;
            (yyval.statement_i).end_num=CreateLabel();
        }
#line 3551 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 218:
#line 1108 "MiniC.y" /* yacc.c:1646  */
    {
            gen_goto((yyvsp[-1].statement_i).end_num);
            gen_label((yyvsp[-5].vint));
            int default_label = -1;
            for (CaseList_t *i = (yyvsp[0].statement_s).caseList; i; i = i->next)
                if (i->isDefault)
                    default_label = i->label;
                else
                    genIfGoto((yyvsp[-3].expression_s), i->value, "==", i->label);
            if (default_label != -1)
                gen_goto(default_label);
            gen_label((yyvsp[-1].statement_i).end_num);
            (yyval.statement_s).caseList=NULL;
        }
#line 3570 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 219:
#line 1124 "MiniC.y" /* yacc.c:1646  */
    {(yyval.statement_i)=(yyvsp[(-5) - (0)].statement_i);}
#line 3576 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 220:
#line 1127 "MiniC.y" /* yacc.c:1646  */
    { /* $0 must be an expression */
            (yyval.vint) = CreateLabel();
            genIfGoto((yyvsp[0].expression_s), "t0", "==", (yyval.vint));
        }
#line 3585 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 221:
#line 1134 "MiniC.y" /* yacc.c:1646  */
    {
            (yyval.vint) = CreateLabel();
            gen_label((yyval.vint));
        }
#line 3594 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 222:
#line 1137 "MiniC.y" /* yacc.c:1646  */
    {
            (yyval.statement_i).has_begin = 1;
            (yyval.statement_i).has_end = 1;
            (yyval.statement_i).begin_num = (yyvsp[-3].vint);
            (yyval.statement_i).end_num = (yyvsp[-1].vint);
            (yyval.statement_i).sblst = NULL;
        }
#line 3606 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 223:
#line 1143 "MiniC.y" /* yacc.c:1646  */
    {gen_goto((yyvsp[-5].vint)); gen_label((yyvsp[-3].vint)); (yyval.statement_s).caseList=NULL;}
#line 3612 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 224:
#line 1144 "MiniC.y" /* yacc.c:1646  */
    {
            (yyval.statement_i).has_begin = 1;
            (yyval.statement_i).has_end = 1;
            (yyval.statement_i).begin_num = CreateLabel();
            (yyval.statement_i).end_num = CreateLabel();
            (yyval.statement_i).sblst = NULL;
            gen_label((yyval.statement_i).begin_num);
        }
#line 3625 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 225:
#line 1151 "MiniC.y" /* yacc.c:1646  */
    {
            genIfGoto((yyvsp[-2].expression_s), "t0", "!=", (yyvsp[-6].statement_i).begin_num);
            gen_label((yyvsp[-6].statement_i).end_num);
            (yyval.statement_s).caseList = NULL;
        }
#line 3635 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 226:
#line 1156 "MiniC.y" /* yacc.c:1646  */
    {
            (yyval.statement_i).has_begin = 1;
            (yyval.statement_i).has_end = 1;
            (yyval.statement_i).begin_num = (yyvsp[-2].vint);
            (yyval.statement_i).end_num = CreateLabel();
            (yyval.statement_i).sblst = NULL;
            if ((yyvsp[-1].expression_statement_s).have)
                genIfGoto((yyvsp[-1].expression_statement_s).expr, "t0", "==", (yyval.statement_i).end_num);
        }
#line 3649 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 227:
#line 1164 "MiniC.y" /* yacc.c:1646  */
    {
            gen_goto((yyvsp[-4].vint));
            gen_label((yyvsp[-1].statement_i).end_num);
            (yyval.statement_s).caseList = NULL;
        }
#line 3659 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 228:
#line 1169 "MiniC.y" /* yacc.c:1646  */
    {
            (yyval.statement_i).has_begin = 1;
            (yyval.statement_i).has_end = 1;
            (yyval.statement_i).begin_num = (yyvsp[-5].vint);
            (yyval.statement_i).end_num = (yyvsp[-3].for_jumper2_s).lb_end;
            (yyval.statement_i).sblst = NULL;
        }
#line 3671 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 229:
#line 1175 "MiniC.y" /* yacc.c:1646  */
    {
            gen_goto((yyvsp[-5].for_jumper2_s).lb_iter);
            gen_label((yyvsp[-5].for_jumper2_s).lb_end);
            (yyval.statement_s).caseList = NULL;
        }
#line 3681 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 230:
#line 1180 "MiniC.y" /* yacc.c:1646  */
    {
            (yyval.statement_i).has_begin = 1;
            (yyval.statement_i).has_end = 1;
            (yyval.statement_i).begin_num = (yyvsp[-2].vint);
            (yyval.statement_i).end_num = CreateLabel();
            (yyval.statement_i).sblst = NULL;
            if ((yyvsp[-1].expression_statement_s).have)
                genIfGoto((yyvsp[-1].expression_statement_s).expr, "t0", "==", (yyval.statement_i).end_num);
        }
#line 3695 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 231:
#line 1188 "MiniC.y" /* yacc.c:1646  */
    {
            gen_goto((yyvsp[-4].vint));
            gen_label((yyvsp[-1].statement_i).end_num);
            (yyval.statement_s).caseList = NULL;
            PopSymbolStack();
        }
#line 3706 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 232:
#line 1194 "MiniC.y" /* yacc.c:1646  */
    {
            (yyval.statement_i).has_begin = 1;
            (yyval.statement_i).has_end = 1;
            (yyval.statement_i).begin_num = (yyvsp[-5].vint);
            (yyval.statement_i).end_num = (yyvsp[-3].for_jumper2_s).lb_end;
            (yyval.statement_i).sblst = NULL;
        }
#line 3718 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 233:
#line 1200 "MiniC.y" /* yacc.c:1646  */
    {
            gen_goto((yyvsp[-5].for_jumper2_s).lb_iter);
            gen_label((yyvsp[-5].for_jumper2_s).lb_end);
            (yyval.statement_s).caseList = NULL;
            PopSymbolStack();
        }
#line 3729 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 234:
#line 1208 "MiniC.y" /* yacc.c:1646  */
    {PushSymbolStack(1);}
#line 3735 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 235:
#line 1211 "MiniC.y" /* yacc.c:1646  */
    { gen_label((yyval.vint) = CreateLabel()); }
#line 3741 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 236:
#line 1214 "MiniC.y" /* yacc.c:1646  */
    {
                    (yyval.for_jumper2_s).lb_end = CreateLabel();
                    if ((yyvsp[0].expression_statement_s).have)
                        genIfGoto((yyvsp[0].expression_statement_s).expr, "t0", "==", (yyval.for_jumper2_s).lb_end);
                    gen_goto((yyval.for_jumper2_s).lb_state = CreateLabel());
                    gen_label((yyval.for_jumper2_s).lb_iter = CreateLabel());
                }
#line 3753 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 237:
#line 1223 "MiniC.y" /* yacc.c:1646  */
    {
                    gen_goto((yyvsp[(-3) - (0)].vint));
                    gen_label(((yyvsp[(-1) - (0)].for_jumper2_s)).lb_state);
                }
#line 3762 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 238:
#line 1230 "MiniC.y" /* yacc.c:1646  */
    {yyerror("no support for goto");}
#line 3768 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 239:
#line 1231 "MiniC.y" /* yacc.c:1646  */
    {
            if ((yyvsp[-2].statement_i).has_begin)
                gen_goto((yyvsp[-2].statement_i).begin_num);
            else
                yyerror("continue error");
            (yyval.statement_s).caseList = NULL;
        }
#line 3780 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 240:
#line 1238 "MiniC.y" /* yacc.c:1646  */
    {
            if ((yyvsp[-2].statement_i).has_end)
                gen_goto((yyvsp[-2].statement_i).end_num);
            else
                yyerror("break error");
            (yyval.statement_s).caseList = NULL;
        }
#line 3792 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 241:
#line 1245 "MiniC.y" /* yacc.c:1646  */
    {
            if (now_func->type->structure->fpointer.type[0]->type != idt_void)
                yyerror("non-void function return void");
            gen_return(NULL);
            (yyval.statement_s).caseList = NULL;
        }
#line 3803 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 242:
#line 1251 "MiniC.y" /* yacc.c:1646  */
    {
            IdType_t ret_type = now_func->type->structure->fpointer.type[0]->type;
            if (ret_type == idt_void)
                yyerror("void function return non-void");
            if (ret_type == idt_union || ret_type == idt_struct)
                yyerror("return union/struct is not support yet");
            char *cast_name = get_cast_name(ret_type, (yyvsp[-1].expression_s).type->type, (yyvsp[-1].expression_s).get_addr());
            gen_return(cast_name);
            (yyval.statement_s).caseList = NULL;
            free(cast_name);
        }
#line 3819 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 247:
#line 1275 "MiniC.y" /* yacc.c:1646  */
    {yyerror("not support this type of function definition");}
#line 3825 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 249:
#line 1276 "MiniC.y" /* yacc.c:1646  */
    {
            if ((yyvsp[-1].declaration_specifiers_s).type==NULL) yyerror("declaration error");
            if ((yyvsp[-1].declaration_specifiers_s).hasTYPEDEF) yyerror("funtion typedef");
            const_Typename_ptr tmptype = (yyvsp[-1].declaration_specifiers_s).type;
            if ((yyvsp[-1].declaration_specifiers_s).hasCONST)
                tmptype = addConst((yyvsp[-1].declaration_specifiers_s).type);
            char *dname = getDeclaratorName(&(yyvsp[0].declarator_s));
            Identifier_t *id2 = (Identifier_t*)LookupSymbol(dname, NULL);
            if (id2 != NULL && id2->type->structure->fpointer.implemented)
                yyerror("identifier already exists");
            Identifier_t *id = StackDeclare(makeType(tmptype, (yyvsp[0].declarator_s)), 0, 0, dname);
            if (id->type->type != idt_fpointer || ((yyvsp[0].declarator_s).dd->type != 5 && (yyvsp[0].declarator_s).dd->type != 6))
                yyerror("function declaration error");
            id->type->structure->fpointer.implemented = 1;
            gen_func(id->TACname, id->type->structure->fpointer.argNum);
            if ((yyvsp[0].declarator_s).dd->type == 5)
                (yyval.statement_i).sblst = (yyvsp[0].declarator_s).dd->data.d5.pl->idList;
            else
                (yyval.statement_i).sblst = NULL;
            (yyval.statement_i).has_begin=0;
            (yyval.statement_i).has_end=0;
            EnterFunc(id);
        }
#line 3853 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;

  case 250:
#line 1298 "MiniC.y" /* yacc.c:1646  */
    {
            //gen_return(NULL);
            gen_endfunc(now_func->TACname);
            LeaveFunc();
        }
#line 3863 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
    break;


#line 3867 "/home/leewy/git/MiniCCompiler/src/parser/MiniC.tab.cpp" /* yacc.c:1646  */
      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYEMPTY : YYTRANSLATE (yychar);

  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
# define YYSYNTAX_ERROR yysyntax_error (&yymsg_alloc, &yymsg, \
                                        yyssp, yytoken)
      {
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = YYSYNTAX_ERROR;
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == 1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = (char *) YYSTACK_ALLOC (yymsg_alloc);
            if (!yymsg)
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = 2;
              }
            else
              {
                yysyntax_error_status = YYSYNTAX_ERROR;
                yymsgp = yymsg;
              }
          }
        yyerror (yymsgp);
        if (yysyntax_error_status == 2)
          goto yyexhaustedlab;
      }
# undef YYSYNTAX_ERROR
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYTERROR;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if !defined yyoverflow || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  return yyresult;
}
#line 1309 "MiniC.y" /* yacc.c:1906  */


void yyerror(const char *s)
{
    puts(s);
    exit(1);
}
